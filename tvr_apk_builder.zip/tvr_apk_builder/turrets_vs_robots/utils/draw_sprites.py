"""
utils/draw_sprites.py — Procedural drawing functions for all game entities.
No external image files required — everything drawn with pygame primitives.
"""

import math
import pygame
from settings import COLORS, CELL_W, CELL_H
from utils.helpers import draw_glow, draw_rounded_rect, clamp


def _surf(w, h):
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    return s

# ─── Turret Sprites ───────────────────────────────────────────────────────────

def draw_turret_base(surface, x, y, color, size=32):
    """Draw a generic turret base hexagon."""
    cx, cy = x + size // 2, y + size // 2
    r = size // 2 - 3
    pts = [(cx + r * math.cos(math.radians(a + 30)), cy + r * math.sin(math.radians(a + 30)))
           for a in range(0, 360, 60)]
    pygame.draw.polygon(surface, (color[0] // 3, color[1] // 3, color[2] // 3), pts)
    pygame.draw.polygon(surface, color, pts, 2)
    pygame.draw.circle(surface, color, (cx, cy), r // 3)

def make_turret_sprite(turret_data, size=50):
    """Create a Surface for a turret based on its data."""
    s = _surf(size, size)
    color = turret_data["color"]
    cx, cy = size // 2, size // 2
    r = size // 2 - 4
    tid = turret_data["id"]

    # Glow
    draw_glow(s, cx, cy, r + 4, color, intensity=0.5)

    # Base hexagon
    pts = [(cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a)))
           for a in range(0, 360, 60)]
    dark = tuple(max(0, c // 4) for c in color)
    pygame.draw.polygon(s, dark, pts)
    pygame.draw.polygon(s, color, pts, 2)

    # Inner detail
    if "cannon" in tid or "gun" in tid or "rifle" in tid or "railgun" in tid:
        # Barrel
        barrel_len = r - 4
        pygame.draw.rect(s, color, (cx, cy - 3, barrel_len, 6), border_radius=2)
        pygame.draw.circle(s, COLORS["white"], (cx, cy), 5)
    elif "generator" in tid or "gen" in tid or "collector" in tid or "reactor" in tid or "cell" in tid or "plant" in tid:
        # Circle energy core
        pygame.draw.circle(s, color, (cx, cy), r // 2)
        pygame.draw.circle(s, COLORS["white"], (cx, cy), r // 4)
        # Radiating lines
        for a in range(0, 360, 45):
            ex = cx + (r - 2) * math.cos(math.radians(a))
            ey = cy + (r - 2) * math.sin(math.radians(a))
            pygame.draw.line(s, color, (cx, cy), (int(ex), int(ey)), 1)
    elif "coil" in tid or "tesla" in tid:
        # Zigzag lightning symbol
        pts2 = [(cx + 5, cy - r + 4), (cx - 2, cy - 2), (cx + 4, cy - 2), (cx - 5, cy + r - 4)]
        pygame.draw.lines(s, color, False, pts2, 2)
    elif "mine" in tid or "spike" in tid:
        # X shape
        for a in [45, 135]:
            ex1 = cx + r * math.cos(math.radians(a))
            ey1 = cy + r * math.sin(math.radians(a))
            ex2 = cx + r * math.cos(math.radians(a + 180))
            ey2 = cy + r * math.sin(math.radians(a + 180))
            pygame.draw.line(s, color, (int(ex1), int(ey1)), (int(ex2), int(ey2)), 3)
    elif "shield" in tid or "mirror" in tid:
        # Shield arc
        rect = pygame.Rect(cx - r + 4, cy - r + 4, (r - 4) * 2, (r - 4) * 2)
        pygame.draw.arc(s, color, rect, math.radians(30), math.radians(150), 4)
        pygame.draw.arc(s, color, rect, math.radians(210), math.radians(330), 4)
    elif "hole" in tid or "gravity" in tid:
        # Concentric circles
        for i in range(3):
            pygame.draw.circle(s, color, (cx, cy), r // 2 - i * 4, 1)
        pygame.draw.circle(s, (0, 0, 0), (cx, cy), 6)
    elif "photon" in tid or "omega" in tid or "overcharge" in tid:
        # Star burst
        for a in range(0, 360, 30):
            ex = cx + r * math.cos(math.radians(a))
            ey = cy + r * math.sin(math.radians(a))
            pygame.draw.line(s, color, (cx, cy), (int(ex), int(ey)), 1)
        pygame.draw.circle(s, color, (cx, cy), r // 3)
    else:
        # Default: dot
        pygame.draw.circle(s, color, (cx, cy), r // 2, 2)
        pygame.draw.circle(s, COLORS["white"], (cx, cy), 4)

    return s


def make_robot_sprite(robot_data, size=40):
    """
    Create a base Surface for a robot. The actual animated drawing is done
    in draw_robot() below — this just returns a placeholder for cache keying.
    We return a tiny surface; draw_robot() is called directly each frame.
    """
    s = _surf(2, 2)
    return s


def draw_robot(surface, robot_data_id, robot_color, robot_size, cx, cy,
               walk_phase=0.0, is_stealth=False, is_attacking=False,
               slow_active=False, burn_active=False, stun_active=False,
               berserker=False, plasma_shields=0, hp_frac=1.0,
               shield_hp_frac=0.0, jammer_active=False):
    """
    Draw a fully procedural animated robot directly onto surface at (cx, cy).
    walk_phase: 0–1 cycling value driving leg/arm swing animation.
    """
    t = pygame.time.get_ticks() / 1000.0
    col = robot_color

    sizes = {
        "small":  {"body_w": 18, "body_h": 20, "leg_l": 10, "arm_l": 8,  "head_r": 7},
        "medium": {"body_w": 24, "body_h": 26, "leg_l": 13, "arm_l": 11, "head_r": 9},
        "large":  {"body_w": 30, "body_h": 32, "leg_l": 16, "arm_l": 14, "head_r": 11},
        "boss":   {"body_w": 40, "body_h": 44, "leg_l": 20, "arm_l": 18, "head_r": 15},
    }
    s = sizes.get(robot_size, sizes["small"])
    bw, bh = s["body_w"], s["body_h"]
    ll, al, hr = s["leg_l"], s["arm_l"], s["head_r"]

    alpha = 60 if is_stealth else 255

    # ── Walking animation angles ─────────────────────────────────────────────
    if is_attacking:
        leg_swing = math.sin(t * 10) * 0.15   # trembling while attacking
        arm_swing = math.sin(t * 10) * 0.4
    else:
        leg_swing = math.sin(walk_phase * math.pi * 2) * 0.55
        arm_swing = -leg_swing * 0.7

    # ── Glow halo ─────────────────────────────────────────────────────────────
    glow_col = col
    if berserker:
        glow_col = COLORS["neon_red"]
        draw_glow(surface, cx, cy, bw + 14, glow_col, intensity=0.5)
    elif stun_active:
        draw_glow(surface, cx, cy, bw + 10, COLORS["neon_yellow"], intensity=0.4)
    elif slow_active:
        draw_glow(surface, cx, cy, bw + 8, COLORS["neon_blue"], intensity=0.3)
    elif burn_active:
        draw_glow(surface, cx, cy, bw + 8, COLORS["neon_orange"], intensity=0.35)
    else:
        draw_glow(surface, cx, cy, bw + 4, col, intensity=0.18)

    dark = tuple(max(0, c // 4) for c in col)
    mid  = tuple(max(0, c // 2) for c in col)
    bright = tuple(min(255, c + 60) for c in col)

    def _draw_limb(x1, y1, x2, y2, thickness, lcolor):
        """Draw a rounded limb segment."""
        pygame.draw.line(surface, lcolor, (x1, y1), (x2, y2), thickness)
        pygame.draw.circle(surface, lcolor, (x2, y2), thickness // 2 + 1)

    body_top = cy - bh // 2
    body_bot = cy + bh // 2

    # ── Legs (2 legs with opposite phase) ────────────────────────────────────
    for side, phase_mul in [(-1, 1), (1, -1)]:
        angle = leg_swing * phase_mul
        foot_x = cx + int(side * (bw // 4 + ll * math.sin(angle)))
        foot_y = body_bot + int(ll * math.cos(angle))
        knee_x = cx + int(side * bw // 4 + side * (ll // 2) * math.sin(angle * 0.5))
        knee_y = body_bot + ll // 2 + 2

        # Upper leg
        _draw_limb(cx + side * bw // 4, body_bot, knee_x, knee_y, max(3, bw // 8), dark)
        # Lower leg
        _draw_limb(knee_x, knee_y, foot_x, foot_y, max(2, bw // 10), mid)
        # Foot pad
        pygame.draw.ellipse(surface, col,
                             pygame.Rect(foot_x - bw // 10, foot_y - 2,
                                         bw // 5, max(3, bw // 14)))

    # ── Arms ──────────────────────────────────────────────────────────────────
    for side, phase_mul in [(-1, -1), (1, 1)]:
        angle = arm_swing * phase_mul
        hand_x = cx + int(side * (bw // 2 + 2 + al * math.sin(angle + 0.3)))
        hand_y = cy - 2 + int(al * math.cos(angle))
        elbow_x = cx + side * (bw // 2 + 1)
        elbow_y = cy - bh // 6

        _draw_limb(elbow_x, elbow_y, hand_x, hand_y, max(2, bw // 10), mid)

        # Weapon/tool on right hand
        if side == 1 and not is_attacking:
            pygame.draw.rect(surface, col,
                             pygame.Rect(hand_x - 1, hand_y - 3, 4, 8), border_radius=1)
        elif side == 1 and is_attacking:
            # Attacking arm punch forward
            muzzle_flash = (int(abs(math.sin(t * 15)) * 200), 200, 50)
            pygame.draw.circle(surface, muzzle_flash, (hand_x, hand_y), 4)

    # ── Torso ─────────────────────────────────────────────────────────────────
    torso_rect = pygame.Rect(cx - bw // 2, body_top, bw, bh)
    pygame.draw.rect(surface, dark, torso_rect, border_radius=4)
    pygame.draw.rect(surface, col, torso_rect, 2, border_radius=4)

    # Chest detail — circuit / energy core
    chest_x, chest_y = cx, cy - 2
    chest_r = bw // 5
    # Glowing core on chest
    pulse = 0.6 + 0.4 * math.sin(t * 3.0 + cx * 0.1)  # each robot slightly offset
    core_color = tuple(min(255, int(c * pulse)) for c in bright)
    pygame.draw.circle(surface, dark, (chest_x, chest_y), chest_r + 2)
    pygame.draw.circle(surface, core_color, (chest_x, chest_y), chest_r)
    pygame.draw.circle(surface, (255, 255, 255), (chest_x, chest_y), max(1, chest_r // 3))

    # Side panel lines on torso
    for lx in [cx - bw // 2 + 4, cx + bw // 2 - 4]:
        pygame.draw.line(surface, mid,
                         (lx, body_top + 4), (lx, body_bot - 4), 1)

    # ── Shoulder pads ─────────────────────────────────────────────────────────
    for side in [-1, 1]:
        pad_rect = pygame.Rect(cx + side * bw // 2 - (3 if side == 1 else -3) - bw // 8,
                                body_top + 2, bw // 4, bh // 3)
        pygame.draw.rect(surface, mid, pad_rect, border_radius=3)
        pygame.draw.rect(surface, col, pad_rect, 1, border_radius=3)

    # ── Head ──────────────────────────────────────────────────────────────────
    head_y = body_top - hr - 1
    # Neck
    pygame.draw.rect(surface, dark,
                     pygame.Rect(cx - hr // 3, body_top - hr // 2, hr // 1.5, hr // 2))
    # Head shape (slightly trapezoidal)
    head_pts = [
        (cx - hr + 3, head_y - hr + 4),
        (cx + hr - 3, head_y - hr + 4),
        (cx + hr,     head_y + hr - 4),
        (cx - hr,     head_y + hr - 4),
    ]
    pygame.draw.polygon(surface, dark, head_pts)
    pygame.draw.polygon(surface, col, head_pts, 2)

    # Visor / face plate
    visor_rect = pygame.Rect(cx - hr + 4, head_y - hr // 2, (hr - 4) * 2, hr // 2 + 2)
    visor_col = (20, 20, 30) if not is_stealth else (50, 50, 80)
    pygame.draw.rect(surface, visor_col, visor_rect, border_radius=2)
    pygame.draw.rect(surface, col, visor_rect, 1, border_radius=2)

    # EYES — the signature glowing red eyes
    eye_y = head_y - hr // 4
    for eye_x in [cx - hr // 2, cx + hr // 2]:
        if is_attacking:
            eye_col = (255, 30, 30)
            eye_r = max(2, hr // 4)
        elif berserker:
            eye_col = (255, 100, 0)
            eye_r = max(3, hr // 3)
        elif stun_active:
            eye_col = (255, 255, 0)
            eye_r = max(2, hr // 4)
        else:
            eye_col = (200 + int(55 * pulse), 20, 20)
            eye_r = max(2, hr // 4)

        draw_glow(surface, eye_x, eye_y, eye_r + 4, eye_col, intensity=0.7)
        pygame.draw.circle(surface, eye_col, (eye_x, eye_y), eye_r)
        # Pupil
        pygame.draw.circle(surface, (255, 180, 180), (eye_x, eye_y), max(1, eye_r // 2))

    # Antenna on boss/large
    if robot_size in ("boss", "large"):
        ant_x = cx
        ant_top = head_y - hr - 8
        pygame.draw.line(surface, col, (ant_x, head_y - hr + 2), (ant_x, ant_top), 1)
        blink = (255, 50, 50) if int(t * 2) % 2 == 0 else (100, 0, 0)
        draw_glow(surface, ant_x, ant_top, 5, blink, intensity=0.6)
        pygame.draw.circle(surface, blink, (ant_x, ant_top), 3)

    # ── Plasma shields (orbiting) ─────────────────────────────────────────────
    if plasma_shields > 0:
        shield_r = bw + 10
        for i in range(plasma_shields):
            angle = t * 2.5 + i * (math.pi * 2 / plasma_shields)
            sx = cx + int(shield_r * math.cos(angle))
            sy = cy + int(shield_r * math.sin(angle) * 0.5)
            draw_glow(surface, sx, sy, 8, COLORS["neon_purple"], intensity=0.8)
            pygame.draw.circle(surface, COLORS["neon_purple"], (sx, sy), 5)
            pygame.draw.circle(surface, (200, 150, 255), (sx, sy), 2)

    # ── Jammer field ─────────────────────────────────────────────────────────
    if jammer_active:
        jammer_r = bw + 30
        jsurf = pygame.Surface((jammer_r * 2, jammer_r * 2), pygame.SRCALPHA)
        pulse_a = int(15 + 10 * math.sin(t * 4))
        pygame.draw.circle(jsurf, (255, 200, 0, pulse_a),
                            (jammer_r, jammer_r), jammer_r)
        pygame.draw.circle(jsurf, (255, 200, 0, 80),
                            (jammer_r, jammer_r), jammer_r, 2)
        surface.blit(jsurf, (cx - jammer_r, cy - jammer_r))


def make_projectile_sprite(proj_type, color, size=8):
    """Create a small projectile surface."""
    s = _surf(size * 2, size * 2)
    cx, cy = size, size

    if proj_type in ("laser",):
        draw_glow(s, cx, cy, size, color, intensity=0.8)
        pygame.draw.circle(s, color, (cx, cy), size // 2)

    elif proj_type in ("arc_ball", "plasma_pierce", "quantum_shot"):
        draw_glow(s, cx, cy, size, color, intensity=0.6)
        pygame.draw.circle(s, color, (cx, cy), max(2, size // 2))
        pygame.draw.circle(s, COLORS["white"], (cx, cy), max(1, size // 4))

    elif proj_type in ("cryo_bolt",):
        draw_glow(s, cx, cy, size, color, intensity=0.5)
        # Snowflake
        for a in range(0, 360, 60):
            ex = cx + size * math.cos(math.radians(a))
            ey = cy + size * math.sin(math.radians(a))
            pygame.draw.line(s, color, (cx, cy), (int(ex), int(ey)), 1)

    elif proj_type in ("flame_stream",):
        draw_glow(s, cx, cy, size, color, intensity=0.7)
        pygame.draw.circle(s, (255, 100, 0), (cx, cy), max(2, size // 2))
        pygame.draw.circle(s, (255, 200, 0), (cx, cy), max(1, size // 3))

    elif proj_type in ("emp_pulse",):
        draw_glow(s, cx, cy, size, color, intensity=0.6)
        pygame.draw.circle(s, color, (cx, cy), size // 2, 2)

    elif proj_type in ("rail_beam",):
        # Big bright bolt
        draw_glow(s, cx, cy, size, color, intensity=1.0)
        pygame.draw.rect(s, color, (cx - size, cy - 2, size * 2, 4))

    elif proj_type in ("homing_missile",):
        draw_glow(s, cx, cy, size, color, intensity=0.6)
        pts = [(cx + size, cy), (cx - size // 2, cy - size // 2), (cx - size // 2, cy + size // 2)]
        pygame.draw.polygon(s, color, pts)

    elif proj_type in ("chain_lightning",):
        draw_glow(s, cx, cy, size, color, intensity=0.9)
        pygame.draw.circle(s, color, (cx, cy), size // 2)

    elif proj_type in ("acid_glob",):
        draw_glow(s, cx, cy, size, (100, 255, 50), intensity=0.5)
        pygame.draw.circle(s, (100, 255, 50), (cx, cy), size // 2)

    elif proj_type in ("sonic_wave",):
        draw_glow(s, cx, cy, size, color, intensity=0.4)
        pygame.draw.circle(s, color, (cx, cy), size // 2, 2)

    else:
        draw_glow(s, cx, cy, size, color, intensity=0.5)
        pygame.draw.circle(s, color, (cx, cy), max(2, size // 2))

    return s


def draw_energy_core(surface, x, y, radius, alpha_frac=1.0):
    """Draw a floating energy core (collectible)."""
    color = COLORS["energy_color"]
    glow_r = int(radius * 2)
    glow_surf = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
    draw_glow(glow_surf, glow_r, glow_r, glow_r, color, intensity=0.5 * alpha_frac)
    surface.blit(glow_surf, (x - glow_r, y - glow_r), special_flags=pygame.BLEND_RGBA_ADD)

    # Hexagonal core
    pts = [(x + radius * math.cos(math.radians(a + 30)),
            y + radius * math.sin(math.radians(a + 30)))
           for a in range(0, 360, 60)]
    col = tuple(int(c * alpha_frac) for c in color)
    pygame.draw.polygon(surface, col, pts)
    white = tuple(int(255 * alpha_frac) for _ in range(3))
    pygame.draw.polygon(surface, white, pts, 1)
    # Inner dot
    pygame.draw.circle(surface, white, (int(x), int(y)), radius // 3)


def draw_explosion(surface, x, y, radius, color, alpha_frac=1.0):
    """Draw an expanding explosion ring."""
    a = int(200 * alpha_frac)
    if a <= 0:
        return
    ring_surf = pygame.Surface((radius * 2 + 20, radius * 2 + 20), pygame.SRCALPHA)
    cx = radius + 10
    cy = radius + 10
    for w in range(3, 0, -1):
        pygame.draw.circle(ring_surf, (*color, a // (w * 2)), (cx, cy), radius, w)
    draw_glow(ring_surf, cx, cy, radius, color, intensity=0.4 * alpha_frac)
    surface.blit(ring_surf, (x - cx, y - cy))


def draw_shield_barrier(surface, x, y, width, height, progress=1.0):
    """Draw a translucent shield barrier."""
    color = COLORS["neon_blue"]
    alpha = int(120 * progress)
    barrier = pygame.Surface((int(width * progress), height), pygame.SRCALPHA)
    barrier.fill((*color, alpha // 3))
    pygame.draw.rect(barrier, (*color, alpha), (0, 0, int(width * progress), height), 2)
    surface.blit(barrier, (x, y))


def draw_background(surface, variant="day_orange", scroll_x=0):
    """
    Draw a rich multi-layer parallax cyberpunk cityscape.
    Layers: sky gradient → nebula/fog → far skyline → mid skyline → near buildings → ground strip.
    """
    import random
    w, h = surface.get_size()
    t = pygame.time.get_ticks() / 1000.0

    # ── Per-variant palette ───────────────────────────────────────────────────
    palettes = {
        "day_orange":       {"sky_top": (8,5,22),    "sky_bot": (45,15,5),
                              "fog": (80,30,10),      "accent": (255,107,0),
                              "accent2": (255,180,60), "ground": (15,8,5)},
        "night_dark":       {"sky_top": (2,2,14),    "sky_bot": (8,8,24),
                              "fog": (10,15,40),      "accent": (0,180,255),
                              "accent2": (0,100,200), "ground": (5,5,15)},
        "swamp_cyan":       {"sky_top": (3,18,22),   "sky_bot": (8,35,30),
                              "fog": (0,60,50),       "accent": (0,255,200),
                              "accent2": (0,200,150), "ground": (5,20,15)},
        "swamp_night_fog":  {"sky_top": (2,10,14),   "sky_bot": (5,20,18),
                              "fog": (10,40,35),      "accent": (0,180,140),
                              "accent2": (0,100,80),  "ground": (3,12,10)},
        "swamp_acid":       {"sky_top": (5,18,5),    "sky_bot": (12,30,5),
                              "fog": (40,80,10),      "accent": (120,255,50),
                              "accent2": (80,200,20), "ground": (8,20,5)},
        "datacenter_blue":  {"sky_top": (3,6,22),    "sky_bot": (10,16,45),
                              "fog": (15,30,80),      "accent": (0,128,255),
                              "accent2": (0,80,200),  "ground": (5,8,25)},
        "datacenter_purple":{"sky_top": (10,3,22),   "sky_bot": (22,8,45),
                              "fog": (40,10,100),     "accent": (191,0,255),
                              "accent2": (120,0,200), "ground": (12,5,28)},
        "orbital_stars":    {"sky_top": (1,1,8),     "sky_bot": (4,4,20),
                              "fog": (5,8,30),        "accent": (80,140,255),
                              "accent2": (40,80,200), "ground": (3,3,18)},
        "orbital_gold":     {"sky_top": (14,10,3),   "sky_bot": (28,22,5),
                              "fog": (60,40,10),      "accent": (255,200,0),
                              "accent2": (200,140,0), "ground": (18,12,3)},
        "core_red":         {"sky_top": (20,2,2),    "sky_bot": (45,8,3),
                              "fog": (100,20,5),      "accent": (255,50,30),
                              "accent2": (200,20,10), "ground": (30,5,3)},
        "core_black":       {"sky_top": (3,1,1),     "sky_bot": (10,3,3),
                              "fog": (30,5,5),        "accent": (180,0,0),
                              "accent2": (120,0,0),   "ground": (8,2,2)},
        "core_omega":       {"sky_top": (18,0,18),   "sky_bot": (40,0,40),
                              "fog": (80,0,80),       "accent": (255,0,220),
                              "accent2": (180,0,160), "ground": (25,0,25)},
    }
    pal = palettes.get(variant, palettes["night_dark"])
    sky_top  = pal["sky_top"]
    sky_bot  = pal["sky_bot"]
    fog_col  = pal["fog"]
    accent   = pal["accent"]
    accent2  = pal["accent2"]
    ground_c = pal["ground"]

    # ── Layer 1: Sky gradient (3-stop) ────────────────────────────────────────
    sky_h = int(h * 0.62)
    for y in range(sky_h):
        t_frac = y / sky_h
        if t_frac < 0.5:
            tf = t_frac * 2
            r = int(sky_top[0] + (fog_col[0] - sky_top[0]) * tf * 0.35)
            g = int(sky_top[1] + (fog_col[1] - sky_top[1]) * tf * 0.35)
            b = int(sky_top[2] + (fog_col[2] - sky_top[2]) * tf * 0.35)
        else:
            tf = (t_frac - 0.5) * 2
            r = int(sky_top[0] * (1-tf) * 0.65 + sky_bot[0] * tf)
            g = int(sky_top[1] * (1-tf) * 0.65 + sky_bot[1] * tf)
            b = int(sky_top[2] * (1-tf) * 0.65 + sky_bot[2] * tf)
        pygame.draw.line(surface, (clamp(r,0,255), clamp(g,0,255), clamp(b,0,255)),
                          (0, y), (w, y))
    # Lower portion
    for y in range(sky_h, h):
        tf = (y - sky_h) / max(1, h - sky_h)
        r = int(sky_bot[0] * (1-tf) + ground_c[0] * tf)
        g = int(sky_bot[1] * (1-tf) + ground_c[1] * tf)
        b = int(sky_bot[2] * (1-tf) + ground_c[2] * tf)
        pygame.draw.line(surface, (clamp(r,0,255), clamp(g,0,255), clamp(b,0,255)),
                          (0, y), (w, y))

    # ── Layer 2: Stars / nebula for dark variants ─────────────────────────────
    if variant in ("night_dark", "orbital_stars", "core_black", "core_omega",
                    "datacenter_purple", "datacenter_blue"):
        rng = random.Random(42)
        for _ in range(120):
            sx = rng.randint(0, w)
            sy = rng.randint(0, int(h * 0.55))
            br = rng.randint(80, 230)
            twinkle = int(20 * math.sin(t * rng.uniform(0.5, 2.5) + sx))
            br = clamp(br + twinkle, 40, 255)
            size = rng.choice([1, 1, 1, 2])
            pygame.draw.circle(surface, (br, br, br), (sx, sy), size)

        # Nebula glow blobs
        rng2 = random.Random(77)
        for _ in range(4):
            nx = rng2.randint(50, w - 50)
            ny = rng2.randint(20, int(h * 0.4))
            nr = rng2.randint(60, 130)
            nc = (rng2.randint(0, 40), rng2.randint(0, 40), rng2.randint(20, 80))
            nsurf = pygame.Surface((nr*2, nr*2), pygame.SRCALPHA)
            pygame.draw.circle(nsurf, (*nc, 18), (nr, nr), nr)
            surface.blit(nsurf, (nx-nr, ny-nr))

    # ── Layer 3: Far background buildings (parallax speed ×0.15) ─────────────
    rng = random.Random(11)
    bx = -int(scroll_x * 0.15) % (w + 300) - 300
    far_h_max = int(sky_h * 0.55)
    while bx < w + 100:
        bw2 = rng.randint(40, 110)
        bh2 = rng.randint(far_h_max // 3, far_h_max)
        by2 = sky_h - bh2
        # Very dark silhouette
        dark_col = tuple(max(0, c // 10) for c in accent)
        pygame.draw.rect(surface, dark_col, (bx, by2, bw2, bh2 + 4))
        # A few lit windows (very dim)
        rng_w = random.Random(bx + 100)
        for wy in range(by2 + 6, by2 + bh2 - 6, 12):
            for wx2 in range(bx + 6, bx + bw2 - 6, 10):
                if rng_w.random() > 0.72:
                    wc = tuple(min(255, c // 3) for c in accent)
                    pygame.draw.rect(surface, wc, (wx2, wy, 4, 5))
        bx += bw2 + rng.randint(8, 40)

    # ── Layer 4: Mid buildings (parallax speed ×0.4) ──────────────────────────
    rng = random.Random(33)
    bx = -int(scroll_x * 0.4) % (w + 400) - 400
    mid_h_max = int(sky_h * 0.8)
    while bx < w + 150:
        bw2 = rng.randint(28, 75)
        bh2 = rng.randint(mid_h_max // 3, mid_h_max)
        by2 = sky_h - bh2
        # Dark body with accent outline
        body_dark = tuple(max(0, c // 6) for c in accent)
        body_edge = tuple(max(0, c // 3) for c in accent)
        pygame.draw.rect(surface, body_dark, (bx, by2, bw2, bh2 + 4))
        pygame.draw.rect(surface, body_edge, (bx, by2, bw2, bh2 + 4), 1)
        # Lit windows
        rng_w = random.Random(bx + 200)
        for wy in range(by2 + 5, by2 + bh2 - 5, 9):
            for wx2 in range(bx + 4, bx + bw2 - 4, 8):
                if rng_w.random() > 0.55:
                    if rng_w.random() > 0.2:
                        wc = tuple(min(255, c + 60) for c in accent2)
                    else:
                        wc = (60, 60, 70)
                    pygame.draw.rect(surface, wc, (wx2, wy, 4, 5))
        # Rooftop antenna / water tower
        if rng.random() > 0.55:
            pygame.draw.line(surface, body_edge,
                              (bx + bw2//2, by2), (bx + bw2//2, by2 - 12), 1)
            blink_c = accent if int(t * 1.5 + bx * 0.01) % 2 == 0 else body_dark
            pygame.draw.circle(surface, blink_c, (bx + bw2//2, by2 - 12), 2)
        bx += bw2 + rng.randint(5, 25)

    # ── Layer 5: Near foreground buildings (parallax speed ×0.7) ─────────────
    rng = random.Random(55)
    bx = -int(scroll_x * 0.7) % (w + 500) - 500
    near_h_max = int(sky_h * 0.65)
    while bx < w + 200:
        bw2 = rng.randint(20, 55)
        bh2 = rng.randint(near_h_max // 4, near_h_max)
        by2 = sky_h - bh2
        # Darker, closer silhouette
        nb_dark = tuple(max(0, c // 8) for c in accent)
        nb_edge = tuple(max(0, c // 4) for c in accent)
        pygame.draw.rect(surface, nb_dark, (bx, by2, bw2, bh2 + 6))
        # Neon trim on near buildings
        pygame.draw.rect(surface, nb_edge, (bx, by2, bw2, bh2 + 6), 1)
        # Horizontal neon band on some buildings
        if rng.random() > 0.5:
            band_y = by2 + bh2 // 3
            band_col = tuple(min(255, c // 2) for c in accent)
            pygame.draw.line(surface, band_col, (bx, band_y), (bx + bw2, band_y), 2)
        # Glowing rooftop
        if rng.random() > 0.4:
            draw_glow(surface, bx + bw2//2, by2 - 2, 8, accent2, intensity=0.25)
        bx += bw2 + rng.randint(3, 18)

    # ── Layer 6: Horizon fog / ground haze ────────────────────────────────────
    fog_surf = pygame.Surface((w, 40), pygame.SRCALPHA)
    for fy in range(40):
        a = int(60 * (1 - fy / 40))
        pygame.draw.line(fog_surf, (*fog_col, a), (0, fy), (w, fy))
    surface.blit(fog_surf, (0, sky_h - 20))

    # ── Layer 7: Ground strip with lane lines ─────────────────────────────────
    ground_rect = pygame.Rect(0, sky_h, w, h - sky_h)
    pygame.draw.rect(surface, ground_c, ground_rect)
    # Subtle ground grid lines
    from settings import GRID_OFFSET_X, GRID_OFFSET_Y, CELL_W, CELL_H, GRID_ROWS, GRID_COLS
    grid_line_c = tuple(max(0, c + 8) for c in ground_c)
    for row in range(GRID_ROWS + 1):
        gy = GRID_OFFSET_Y + row * CELL_H
        if gy > sky_h:
            pygame.draw.line(surface, grid_line_c, (0, gy), (w, gy))

    # ── Atmospheric glow above grid area ─────────────────────────────────────
    atmo = pygame.Surface((w, 60), pygame.SRCALPHA)
    for ay in range(60):
        a = int(30 * (1 - ay / 60))
        ac = tuple(min(255, c + 20) for c in accent)
        pygame.draw.line(atmo, (*ac, a), (0, ay), (w, ay))
    surface.blit(atmo, (0, sky_h - 30))


def draw_scanline_overlay(surface):
    """Draw a CRT scanline effect at very low opacity."""
    w, h = surface.get_size()
    scan_surf = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(0, h, 3):
        pygame.draw.line(scan_surf, (0, 0, 0, 18), (0, y), (w, y))
    surface.blit(scan_surf, (0, 0))


def draw_grid_cell(surface, rect, modifier=None, hovered=False, has_unit=False):
    """Draw a single grid cell with circuit-board pattern."""
    x, y, w, h = rect.x, rect.y, rect.width, rect.height
    # Base fill
    if hovered:
        pygame.draw.rect(surface, COLORS["grid_hover"], rect)
    else:
        pygame.draw.rect(surface, COLORS["grid_cell"], rect)

    # Modifier tint
    if modifier == "flooded":
        tint = pygame.Surface((w, h), pygame.SRCALPHA)
        tint.fill((0, 100, 200, 30))
        surface.blit(tint, rect.topleft)
    elif modifier == "emf_zone":
        tint = pygame.Surface((w, h), pygame.SRCALPHA)
        tint.fill((255, 200, 0, 20))
        surface.blit(tint, rect.topleft)
    elif modifier == "darkness":
        tint = pygame.Surface((w, h), pygame.SRCALPHA)
        tint.fill((0, 0, 0, 80))
        surface.blit(tint, rect.topleft)

    # Circuit lines
    cx, cy = x + w // 2, y + h // 2
    line_color = COLORS["grid_line"]
    pygame.draw.line(surface, line_color, (x + 4, cy), (x + w // 3, cy), 1)
    pygame.draw.line(surface, line_color, (x + w // 3, cy), (x + w // 3, y + 4), 1)
    pygame.draw.line(surface, line_color, (x + 2 * w // 3, cy), (x + w - 4, cy), 1)
    pygame.draw.line(surface, line_color, (x + 2 * w // 3, cy), (x + 2 * w // 3, y + h - 4), 1)

    # Border
    border_col = COLORS["ui_border_hi"] if hovered else COLORS["grid_line"]
    pygame.draw.rect(surface, border_col, rect, 1)
