"""
utils/helpers.py — Timer, cooldown, math utilities, and font manager.
"""

import math
import pygame
from settings import COLORS, FONT_SIZES

# ─── Font Manager ─────────────────────────────────────────────────────────────
_fonts = {}

def get_font(size_name: str = "medium") -> pygame.font.Font:
    """Return a cached pygame font by size name."""
    if size_name not in _fonts:
        pt = FONT_SIZES.get(size_name, 20)
        try:
            # Try to use a monospace system font for that sci-fi feel
            _fonts[size_name] = pygame.font.SysFont("courier", pt, bold=True)
        except Exception:
            _fonts[size_name] = pygame.font.Font(None, pt + 4)
    return _fonts[size_name]

def render_text(surface, text, x, y, color=None, size="medium", center=False, shadow=True):
    """Render text with optional drop shadow onto surface."""
    if color is None:
        color = COLORS["text_primary"]
    font = get_font(size)
    if shadow:
        shadow_surf = font.render(text, True, (0, 0, 0))
        r = shadow_surf.get_rect()
        if center:
            r.center = (x, y)
        else:
            r.topleft = (x, y)
        surface.blit(shadow_surf, (r.x + 1, r.y + 1))
    text_surf = font.render(text, True, color)
    r = text_surf.get_rect()
    if center:
        r.center = (x, y)
    else:
        r.topleft = (x, y)
    surface.blit(text_surf, r)
    return r

# ─── Cooldown Timer ───────────────────────────────────────────────────────────
class Cooldown:
    """Tracks a recharge timer. Returns True when ready."""
    def __init__(self, duration: float, ready: bool = True):
        self.duration = duration
        self._elapsed = duration if ready else 0.0

    def update(self, dt: float):
        if self._elapsed < self.duration:
            self._elapsed = min(self._elapsed + dt, self.duration)

    def ready(self) -> bool:
        return self._elapsed >= self.duration

    def use(self):
        self._elapsed = 0.0

    def fraction(self) -> float:
        """0.0 = just used, 1.0 = fully recharged."""
        return self._elapsed / self.duration if self.duration > 0 else 1.0

    def reset(self):
        self._elapsed = self.duration


# ─── Math helpers ─────────────────────────────────────────────────────────────
def lerp(a, b, t):
    return a + (b - a) * t

def clamp(value, lo, hi):
    return max(lo, min(hi, value))

def dist(ax, ay, bx, by):
    return math.sqrt((ax - bx) ** 2 + (ay - by) ** 2)

def angle_to(ax, ay, bx, by):
    return math.atan2(by - ay, bx - ax)

def normalize(dx, dy):
    length = math.sqrt(dx * dx + dy * dy)
    if length == 0:
        return 0.0, 0.0
    return dx / length, dy / length

def grid_to_pixel(col, row):
    """Return the center pixel of a grid cell (col, row)."""
    from settings import GRID_OFFSET_X, GRID_OFFSET_Y, CELL_W, CELL_H
    return (GRID_OFFSET_X + col * CELL_W + CELL_W // 2,
            GRID_OFFSET_Y + row * CELL_H + CELL_H // 2)

def pixel_to_grid(px, py):
    """Convert pixel coords to (col, row). Returns None if outside grid."""
    from settings import GRID_OFFSET_X, GRID_OFFSET_Y, CELL_W, CELL_H, GRID_COLS, GRID_ROWS
    col = (px - GRID_OFFSET_X) // CELL_W
    row = (py - GRID_OFFSET_Y) // CELL_H
    if 0 <= col < GRID_COLS and 0 <= row < GRID_ROWS:
        return int(col), int(row)
    return None

# ─── Draw Helpers ─────────────────────────────────────────────────────────────
def draw_rounded_rect(surface, rect, color, radius=8, border=0, border_color=None):
    """Draw a rounded rectangle with optional border."""
    pygame.draw.rect(surface, color, rect, border_radius=radius)
    if border and border_color:
        pygame.draw.rect(surface, border_color, rect, border, border_radius=radius)

def draw_glow(surface, x, y, radius, color, intensity=0.4):
    """Draw a soft glow circle using a temp alpha surface."""
    glow_surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
    for r in range(radius, 0, -max(1, radius // 8)):
        alpha = int(intensity * 255 * (1 - r / radius) ** 1.5)
        alpha = clamp(alpha, 0, 255)
        c = (color[0], color[1], color[2], alpha)
        pygame.draw.circle(glow_surf, c, (radius, radius), r)
    surface.blit(glow_surf, (x - radius, y - radius), special_flags=pygame.BLEND_RGBA_ADD)

def draw_hp_bar(surface, x, y, w, h, current, maximum, border_radius=3):
    """Draw a health bar (red/green fill with dark background)."""
    pygame.draw.rect(surface, COLORS["hp_bar_bg"], (x, y, w, h), border_radius=border_radius)
    if maximum > 0:
        frac = clamp(current / maximum, 0, 1)
        color = COLORS["hp_green"] if frac > 0.5 else (
            COLORS["neon_yellow"] if frac > 0.25 else COLORS["hp_red"])
        if frac > 0:
            pygame.draw.rect(surface, color, (x, y, int(w * frac), h), border_radius=border_radius)

def draw_neon_circle(surface, x, y, radius, color, width=2):
    """Draw a neon circle with a glow halo."""
    draw_glow(surface, x, y, radius + 6, color, intensity=0.3)
    pygame.draw.circle(surface, color, (x, y), radius, width)
