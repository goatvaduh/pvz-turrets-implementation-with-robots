"""
main.py — Entry point for Turrets vs Robots (Android / desktop).
Uses a plain synchronous loop; python-for-android runs it via PythonActivity.
"""
import sys, os
try:
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
except Exception:
    pass

import pygame
from settings import SCREEN_W, SCREEN_H, FPS, TITLE

_LOGICAL_W = SCREEN_W
_LOGICAL_H = SCREEN_H
_active_touches: dict = {}

def _touch_to_mouse(event, win_w, win_h):
    px = int(event.x * win_w)
    py = int(event.y * win_h)
    pygame.mouse.set_pos(px, py)
    if event.type == pygame.FINGERDOWN:
        _active_touches[event.finger_id] = (px, py)
        return [pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(px,py), button=1)]
    elif event.type == pygame.FINGERUP:
        _active_touches.pop(event.finger_id, None)
        return [pygame.event.Event(pygame.MOUSEBUTTONUP, pos=(px,py), button=1)]
    elif event.type == pygame.FINGERMOTION:
        _active_touches[event.finger_id] = (px, py)
        return [pygame.event.Event(pygame.MOUSEMOTION, pos=(px,py),
                rel=(int(event.dx*win_w), int(event.dy*win_h)), buttons=(1,0,0))]
    return []

def main():
    pygame.init()

    # On Android, SCALED fills the screen; on desktop opens a fixed window
    flags = pygame.SCALED | pygame.RESIZABLE
    screen = pygame.display.set_mode((_LOGICAL_W, _LOGICAL_H), flags)
    pygame.display.set_caption(TITLE)
    clock = pygame.time.Clock()

    try:
        pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
    except Exception:
        pass

    from game.state_manager import StateManager
    manager = StateManager()
    running = True

    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        win_w, win_h = screen.get_size()

        all_events = []
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break
            if event.type in (pygame.FINGERDOWN, pygame.FINGERUP, pygame.FINGERMOTION):
                all_events.extend(_touch_to_mouse(event, win_w, win_h))
            else:
                all_events.append(event)

        for event in all_events:
            manager.handle_event(event)

        manager.update(dt)
        manager.draw(screen)
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
