"""
data/robots_data.py — Data-driven definitions for all enemy robots.
No game logic — pure data.
"""

ROBOTS = {
    # ── Tier 1 Scout Robots ───────────────────────────────────────────────────
    "crawler": {
        "id": "crawler", "name": "Crawler Bot",
        "hp": 100, "speed": 0.45, "armor": 0, "damage": 60, "attack_rate": 1.0,
        "special": None, "color": (220, 80, 50), "size": "small", "score_value": 10,
        "description": "Basic unit. No tricks.",
    },
    "rusher": {
        "id": "rusher", "name": "Rusher",
        "hp": 80, "speed": 1.1, "armor": 0, "damage": 40, "attack_rate": 1.5,
        "special": None, "color": (255, 140, 0), "size": "small", "score_value": 15,
        "description": "Double speed, half HP. Rushes your defenses.",
    },
    "shielder": {
        "id": "shielder", "name": "Shielder Bot",
        "hp": 150, "speed": 0.65, "armor": 0, "damage": 60, "attack_rate": 0.8,
        "special": "front_shield_50", "color": (100, 180, 255), "size": "small", "score_value": 20,
        "description": "Front shield absorbs first 50 damage.",
    },
    "exploder": {
        "id": "exploder", "name": "Exploder",
        "hp": 120, "speed": 0.75, "armor": 0, "damage": 80, "attack_rate": 1.0,
        "special": "death_explode_30", "color": (255, 80, 0), "size": "small", "score_value": 20,
        "description": "Explodes on death, dealing 30 dmg to adjacent turrets.",
    },
    "stealth_bot": {
        "id": "stealth_bot", "name": "Stealth Bot",
        "hp": 100, "speed": 0.9, "armor": 0, "damage": 60, "attack_rate": 1.2,
        "special": "stealth_until_attack", "color": (80, 80, 120), "size": "small", "score_value": 25,
        "description": "Invisible until it attacks. Pulse Turrets can't target it.",
    },

    # ── Tier 2 Combat Robots ──────────────────────────────────────────────────
    "tank_bot": {
        "id": "tank_bot", "name": "Tank Bot",
        "hp": 400, "speed": 0.4, "armor": 20, "damage": 100, "attack_rate": 0.7,
        "special": None, "color": (150, 150, 150), "size": "medium", "score_value": 40,
        "description": "High armor — flat 20 damage reduction.",
    },
    "repair_drone": {
        "id": "repair_drone", "name": "Repair Drone",
        "hp": 150, "speed": 0.9, "armor": 0, "damage": 30, "attack_rate": 1.0,
        "special": "heal_nearest_30ps", "color": (0, 255, 180), "size": "small", "score_value": 35,
        "description": "Heals nearest robot 30 HP/s. Destroy it first!",
    },
    "jammer_bot": {
        "id": "jammer_bot", "name": "Jammer",
        "hp": 180, "speed": 0.7, "armor": 0, "damage": 50, "attack_rate": 0.9,
        "special": "double_turret_cooldowns", "color": (200, 200, 0), "size": "small", "score_value": 35,
        "description": "Emits field doubling nearby turret cooldowns.",
    },
    "splitter": {
        "id": "splitter", "name": "Splitter",
        "hp": 200, "speed": 0.6, "armor": 0, "damage": 70, "attack_rate": 0.8,
        "special": "split_2_crawlers", "color": (150, 255, 100), "size": "medium", "score_value": 30,
        "description": "Splits into 2 Crawlers on death.",
    },
    "jumper_bot": {
        "id": "jumper_bot", "name": "Jumper",
        "hp": 160, "speed": 0.75, "armor": 0, "damage": 60, "attack_rate": 1.0,
        "special": "jump_over_first_turret", "color": (100, 255, 255), "size": "small", "score_value": 30,
        "description": "Leaps over the first turret it encounters.",
    },
    "reflector_bot": {
        "id": "reflector_bot", "name": "Reflector",
        "hp": 200, "speed": 0.6, "armor": 0, "damage": 60, "attack_rate": 0.8,
        "special": "reflect_30pct", "color": (180, 180, 255), "size": "medium", "score_value": 35,
        "description": "30% chance to reflect projectiles back at turrets.",
    },
    "corrosive_bot": {
        "id": "corrosive_bot", "name": "Corrosive",
        "hp": 200, "speed": 0.7, "armor": 0, "damage": 60, "attack_rate": 0.9,
        "special": "acid_trail", "color": (100, 200, 50), "size": "medium", "score_value": 35,
        "description": "Leaves acid trail damaging turrets it passes.",
    },

    # ── Tier 3 Heavy Robots ───────────────────────────────────────────────────
    "siege_walker": {
        "id": "siege_walker", "name": "Siege Walker",
        "hp": 600, "speed": 0.3, "armor": 10, "damage": 120, "attack_rate": 0.6,
        "special": "mortar_3ahead", "color": (180, 100, 50), "size": "large", "score_value": 80,
        "description": "Has a mortar lobbing shots at turrets 3 cells ahead.",
    },
    "tesla_bot": {
        "id": "tesla_bot", "name": "Tesla Bot",
        "hp": 350, "speed": 0.55, "armor": 5, "damage": 80, "attack_rate": 0.8,
        "special": "discharge_on_hit", "color": (255, 255, 100), "size": "medium", "score_value": 60,
        "description": "Discharges electricity when hit, briefly stunning nearby turrets.",
    },
    "phase_bot": {
        "id": "phase_bot", "name": "Phase Bot",
        "hp": 300, "speed": 0.7, "armor": 0, "damage": 80, "attack_rate": 0.9,
        "special": "phase_through_one", "color": (200, 100, 255), "size": "medium", "score_value": 55,
        "description": "Can phase through the first turret in its lane.",
    },
    "berserker": {
        "id": "berserker", "name": "Berserker",
        "hp": 450, "speed": 0.5, "armor": 5, "damage": 90, "attack_rate": 0.7,
        "special": "berserker_below_50pct", "color": (255, 30, 30), "size": "large", "score_value": 70,
        "description": "Below 50% HP: speed doubles and damage triples.",
    },
    "ghost_walker": {
        "id": "ghost_walker", "name": "Ghost Walker",
        "hp": 250, "speed": 0.85, "armor": 0, "damage": 70, "attack_rate": 1.0,
        "special": "ignore_passive_traps", "color": (200, 200, 255), "size": "medium", "score_value": 60,
        "description": "Ignores spike/passive traps. Only hittable by direct fire.",
    },
    "swarm_core": {
        "id": "swarm_core", "name": "Swarm Core",
        "hp": 300, "speed": 0.4, "armor": 5, "damage": 70, "attack_rate": 0.7,
        "special": "spawn_drones_8s", "color": (0, 200, 100), "size": "medium", "score_value": 75,
        "description": "Deploys 4 mini-drones every 8s until destroyed.",
    },
    "nano_cloud": {
        "id": "nano_cloud", "name": "Nano Cloud",
        "hp": 350, "speed": 0.6, "armor": 0, "damage": 70, "attack_rate": 0.8,
        "special": "absorb_1proj_per_sec", "color": (50, 200, 200), "size": "medium", "score_value": 70,
        "description": "Absorbs 1 projectile per second, converting it to HP.",
    },

    # ── Tier 4 Elite Robots ───────────────────────────────────────────────────
    "titan_chassis": {
        "id": "titan_chassis", "name": "Titan Chassis",
        "hp": 1200, "speed": 0.25, "armor": 30, "damage": 200, "attack_rate": 0.5,
        "special": "attack_all_in_lane", "color": (100, 100, 100), "size": "large", "score_value": 150,
        "description": "Massive. Attacks ALL turrets in its lane simultaneously.",
    },
    "mimic_bot": {
        "id": "mimic_bot", "name": "Mimic Bot",
        "hp": 400, "speed": 0.7, "armor": 0, "damage": 80, "attack_rate": 0.9,
        "special": "copy_turret_special", "color": (180, 0, 180), "size": "medium", "score_value": 100,
        "description": "Copies the special ability of the last turret that hit it.",
    },
    "warp_drone": {
        "id": "warp_drone", "name": "Warp Drone",
        "hp": 200, "speed": 1.2, "armor": 0, "damage": 60, "attack_rate": 1.2,
        "special": "teleport_2cells_5s", "color": (100, 255, 200), "size": "small", "score_value": 80,
        "description": "Teleports 2 cells forward every 5s.",
    },
    "plasma_knight": {
        "id": "plasma_knight", "name": "Plasma Knight",
        "hp": 700, "speed": 0.4, "armor": 15, "damage": 120, "attack_rate": 0.6,
        "special": "plasma_shields_3", "color": (255, 150, 255), "size": "large", "score_value": 130,
        "description": "Protected by 3 rotating plasma shields. Destroy shields first.",
    },
    "overclock_bot": {
        "id": "overclock_bot", "name": "Overclock Bot",
        "hp": 500, "speed": 0.65, "armor": 10, "damage": 100, "attack_rate": 0.7,
        "special": "boost_nearby_speed_50pct", "color": (255, 255, 0), "size": "large", "score_value": 120,
        "description": "Boosts nearby robots' speed by 50%.",
    },

    # ── Boss Robots ───────────────────────────────────────────────────────────
    "crusher_mk1": {
        "id": "crusher_mk1", "name": "Crusher MK-I",
        "hp": 2000, "speed": 0.35, "armor": 20, "damage": 250, "attack_rate": 0.5,
        "special": "immune_slow", "color": (200, 50, 50), "size": "boss", "score_value": 500,
        "description": "Boss 1. Immune to slows. Bulldozes everything.",
    },
    "hive_mother": {
        "id": "hive_mother", "name": "Hive Mother",
        "hp": 2500, "speed": 0.25, "armor": 15, "damage": 150, "attack_rate": 0.6,
        "special": "spawn_crawlers_5s", "color": (0, 180, 80), "size": "boss", "score_value": 600,
        "description": "Boss 2. Constantly spawns Crawlers.",
    },
    "void_walker": {
        "id": "void_walker", "name": "Void Walker",
        "hp": 3000, "speed": 0.4, "armor": 25, "damage": 200, "attack_rate": 0.5,
        "special": "phase_invisible_start", "color": (50, 0, 100), "size": "boss", "score_value": 700,
        "description": "Boss 3. Starts invisible, then charges all lanes.",
    },
    "omega_unit": {
        "id": "omega_unit", "name": "OMEGA UNIT",
        "hp": 10000, "speed": 0.3, "armor": 50, "damage": 400, "attack_rate": 0.4,
        "special": "multi_phase_boss", "color": (255, 0, 100), "size": "boss", "score_value": 5000,
        "description": "Final Boss. Three phases. True nightmare.",
    },
}
