[app]
title = Turrets vs Robots
package.name = turretsvrobots
package.domain = com.turretsgame

source.dir = .
source.include_exts = py,png,json
source.exclude_dirs = build,__pycache__,.github,icons

version = 1.0

# pygame-ce is better maintained for Android than plain pygame
requirements = python3,pygame

orientation = landscape
fullscreen = 1

icon.filename = %(source.dir)s/icon.png
presplash.filename = %(source.dir)s/splash.png
presplash.color = #0a0e1a

android.minapi = 21
android.api = 33
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.permissions = VIBRATE, WAKE_LOCK
android.wakelock = True

[buildozer]
log_level = 2
warn_on_root = 0
