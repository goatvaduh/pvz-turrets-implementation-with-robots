"""
game/particle.py — Particle system for sparks, trails, explosions, and glows.
Capped at MAX_PARTICLES for performance.
"""

import math
import random
import pygame
from settings import MAX_PARTICLES, COLORS
from utils.helpers import clamp


class Particle:
    """Single particle with physics and fade."""
    __slots__ = ["x", "y", "vx", "vy", "lifetime", "max_life", "color", "size", "gravity"]

    def __init__(self, x, y, vx, vy, lifetime, color, size=3, gravity=0.0):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.lifetime = lifetime
        self.max_life = lifetime
        self.color = color
        self.size = size
        self.gravity = gravity

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += self.gravity * dt
        self.lifetime -= dt
        return self.lifetime > 0

    def draw(self, surface):
        frac = clamp(self.lifetime / self.max_life, 0, 1)
        alpha = int(255 * frac)
        r = max(1, int(self.size * frac))
        # Use a small alpha surface for smooth fade
        ps = pygame.Surface((r * 2 + 1, r * 2 + 1), pygame.SRCALPHA)
        c = (*self.color, alpha)
        pygame.draw.circle(ps, c, (r, r), r)
        surface.blit(ps, (int(self.x) - r, int(self.y) - r))


class ParticleSystem:
    """Manages all active particles with a hard cap."""

    def __init__(self):
        self.particles: list[Particle] = []

    def _add(self, p: Particle):
        if len(self.particles) < MAX_PARTICLES:
            self.particles.append(p)

    def emit_burst(self, x, y, color, count=12, speed=80, size=3, lifetime=0.5, gravity=50.0):
        """Explosive burst of particles."""
        for _ in range(count):
            angle = random.uniform(0, math.pi * 2)
            spd = random.uniform(speed * 0.4, speed)
            vx = math.cos(angle) * spd
            vy = math.sin(angle) * spd
            lt = random.uniform(lifetime * 0.5, lifetime)
            self._add(Particle(x, y, vx, vy, lt, color, size, gravity))

    def emit_trail(self, x, y, color, direction_angle=math.pi, speed=40, size=2, lifetime=0.2):
        """Single trail particle (call each frame for continuous trail)."""
        spread = math.pi / 4
        angle = direction_angle + random.uniform(-spread, spread)
        vx = math.cos(angle) * random.uniform(speed * 0.3, speed)
        vy = math.sin(angle) * random.uniform(speed * 0.3, speed)
        self._add(Particle(x, y, vx, vy, lifetime, color, size, 0))

    def emit_spark(self, x, y, color, count=5):
        """Small electrical spark effect."""
        for _ in range(count):
            angle = random.uniform(0, math.pi * 2)
            spd = random.uniform(20, 100)
            vx = math.cos(angle) * spd
            vy = math.sin(angle) * spd
            self._add(Particle(x, y, vx, vy,
                                random.uniform(0.1, 0.3),
                                color, random.randint(1, 3), 20))

    def emit_energy_pulse(self, x, y, count=8):
        """Yellow energy collect effect."""
        color = COLORS["energy_color"]
        for _ in range(count):
            angle = random.uniform(0, math.pi * 2)
            spd = random.uniform(30, 80)
            self._add(Particle(x, y,
                                math.cos(angle) * spd,
                                math.sin(angle) * spd - 40,
                                random.uniform(0.3, 0.6), color, 3, -20))

    def emit_explosion(self, x, y, color=None, radius=40):
        """Large explosion burst."""
        if color is None:
            color = COLORS["neon_orange"]
        self.emit_burst(x, y, color, count=20, speed=radius * 2, size=4, lifetime=0.6, gravity=80)
        self.emit_burst(x, y, COLORS["neon_yellow"], count=10, speed=radius, size=2, lifetime=0.4, gravity=40)

    def emit_laser_hit(self, x, y, color):
        """Small hit effect at laser impact point."""
        self.emit_burst(x, y, color, count=8, speed=60, size=2, lifetime=0.3, gravity=0)

    def emit_freeze(self, x, y):
        """Ice crystal burst for cryo effects."""
        color = COLORS["neon_blue"]
        for _ in range(12):
            angle = random.uniform(0, math.pi * 2)
            spd = random.uniform(20, 60)
            self._add(Particle(x, y,
                                math.cos(angle) * spd,
                                math.sin(angle) * spd,
                                random.uniform(0.4, 0.8), color, 2, 0))

    def emit_chain_lightning(self, x1, y1, x2, y2):
        """Sparks along a lightning path."""
        steps = 8
        for i in range(steps):
            t = i / steps
            px = x1 + (x2 - x1) * t + random.uniform(-10, 10)
            py = y1 + (y2 - y1) * t + random.uniform(-10, 10)
            self._add(Particle(px, py, 0, 0, 0.15, COLORS["neon_yellow"], 2, 0))

    def update(self, dt):
        self.particles = [p for p in self.particles if p.update(dt)]

    def draw(self, surface):
        for p in self.particles:
            p.draw(surface)

    def clear(self):
        self.particles.clear()
