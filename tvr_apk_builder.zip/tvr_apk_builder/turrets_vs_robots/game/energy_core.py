"""
game/energy_core.py — Floating energy core collectibles that drop from generators.
"""

import math
import random
import pygame
from settings import (COLORS, ENERGY_CORE_VALUE, ENERGY_CORE_LIFETIME,
                       ENERGY_CORE_RADIUS, GRID_OFFSET_X, GRID_OFFSET_Y,
                       GRID_COLS, CELL_W, GRID_ROWS, CELL_H)
from utils.draw_sprites import draw_energy_core
from utils.helpers import clamp


class EnergyCore:
    """A collectible energy core that bobs and fades before disappearing."""

    def __init__(self, x: float, y: float, value: int = None):
        self.x = float(x)
        self.y = float(y)
        self.target_y = float(y)      # where it floats to
        self.start_y = y - 30         # starts above, drops down
        self.drop_y = y               # final resting position
        self.value = value if value else ENERGY_CORE_VALUE
        self.lifetime = ENERGY_CORE_LIFETIME
        self.alive = True
        self.collected = False
        self.radius = ENERGY_CORE_RADIUS
        self._bob_phase = random.uniform(0, math.pi * 2)
        self._drop_elapsed = 0.0
        self._drop_duration = 0.5     # seconds to fall into position
        self._dropping = True
        self._flash_timer = 0.0

        # Sky-drop cores (from the drip system) come from above
        self.y = self.start_y

    def update(self, dt):
        if not self.alive:
            return

        self.lifetime -= dt
        if self.lifetime <= 0:
            self.alive = False
            return

        # Drop animation
        if self._dropping:
            self._drop_elapsed += dt
            t = clamp(self._drop_elapsed / self._drop_duration, 0, 1)
            # Ease-out
            t = 1 - (1 - t) ** 2
            self.y = self.start_y + (self.drop_y - self.start_y) * t
            if t >= 1.0:
                self._dropping = False
        else:
            # Bob up and down
            self._bob_phase += dt * 2.5
            self.y = self.drop_y + math.sin(self._bob_phase) * 3

        # Flash when about to expire
        if self.lifetime < 3.0:
            self._flash_timer += dt

    def alpha_fraction(self) -> float:
        """0–1 fade as lifetime drops."""
        if self.lifetime > 3.0:
            return 1.0
        return clamp(self.lifetime / 3.0, 0, 1)

    def collect(self):
        self.collected = True
        self.alive = False
        return self.value

    def hit_test(self, px, py) -> bool:
        return (abs(px - self.x) < self.radius + 10 and
                abs(py - self.y) < self.radius + 10)

    def draw(self, surface):
        if not self.alive:
            return
        # Flash effect when about to expire
        if self.lifetime < 3.0 and int(self._flash_timer * 6) % 2 == 1:
            return
        draw_energy_core(surface, int(self.x), int(self.y),
                          self.radius, self.alpha_fraction())


class SkyDropSystem:
    """Periodically drops energy cores from the sky (background drip rate)."""

    def __init__(self, interval: float = 8.0):
        self.interval = interval
        self._timer = 0.0
        self.enabled = True

    def update(self, dt) -> list:
        """Returns list of new EnergyCore objects to add."""
        if not self.enabled:
            return []
        self._timer += dt
        if self._timer >= self.interval:
            self._timer = 0.0
            # Drop at a random column in the grid
            col = random.randint(0, GRID_COLS - 1)
            row = random.randint(0, GRID_ROWS - 1)
            x = GRID_OFFSET_X + col * CELL_W + CELL_W // 2 + random.uniform(-15, 15)
            y_drop = GRID_OFFSET_Y + row * CELL_H + CELL_H // 2
            return [EnergyCore(x, y_drop)]
        return []
