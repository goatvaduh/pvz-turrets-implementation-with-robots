"""
game/state_manager.py — Manages transitions between all game screens.
Screens: MainMenu, LevelSelect, Gameplay, Paused, Win, Lose, HowToPlay.
"""

import math
import pygame
import json
import os
from settings import (COLORS, SCREEN_W, SCREEN_H, STATE_MENU, STATE_PLAYING,
                       STATE_PAUSED, STATE_WIN, STATE_LOSE, STATE_LEVEL_SELECT,
                       STATE_HOW_TO_PLAY, SAVE_FILE)
from utils.helpers import render_text, draw_rounded_rect, draw_glow, get_font
from utils.draw_sprites import draw_background, draw_scanline_overlay, make_robot_sprite
from data.robots_data import ROBOTS
from data.levels_data import LEVELS


# ─── Save data helpers ────────────────────────────────────────────────────────

def load_save() -> dict:
    try:
        with open(SAVE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {"unlocked_levels": [1], "stars": {}, "high_scores": {}}

def write_save(data: dict):
    try:
        with open(SAVE_FILE, "w") as f:
            json.dump(data, f)
    except Exception:
        pass


# ─── Button helper ────────────────────────────────────────────────────────────

class Button:
    def __init__(self, label, x, y, w=200, h=40, color=None):
        self.label = label
        self.rect = pygame.Rect(x - w // 2, y - h // 2, w, h)
        self.color = color or COLORS["neon_cyan"]
        self.hovered = False

    def draw(self, surface):
        bg = (30, 50, 80) if self.hovered else COLORS["ui_panel"]
        border = self.color if self.hovered else COLORS["ui_border"]
        draw_rounded_rect(surface, self.rect, bg, radius=8, border=2, border_color=border)
        render_text(surface, self.label, self.rect.centerx, self.rect.centery,
                     self.color if self.hovered else COLORS["text_primary"],
                     size="medium", center=True)

    def handle(self, mx, my):
        self.hovered = self.rect.collidepoint(mx, my)
        return self.hovered

    def clicked(self, mx, my):
        return self.rect.collidepoint(mx, my)


# ─── State Manager ────────────────────────────────────────────────────────────

class StateManager:
    """Top-level controller switching between game screens."""

    def __init__(self):
        self.state = STATE_MENU
        self.save = load_save()
        self._gameplay = None
        self._selected_level = 1
        self._menu_scroll = 0.0
        self._menu_robot_x = -80.0
        self._result_timer = 0.0
        self._pause_buttons = []
        self._win_score = 0
        self._win_stars = 0
        self._robots_through = 0
        self._drones_left = 0
        self._earned_nc = 0
        self._title_glow = 0.0
        self._particles_surface = None
        self._init_menu_robots()

    def _init_menu_robots(self):
        self._menu_robots = [
            {"id": "crawler", "x": -80, "y": SCREEN_H - 60, "speed": 45},
            {"id": "rusher",  "x": -200, "y": SCREEN_H - 55, "speed": 70},
        ]
        for mr in self._menu_robots:
            mr["sprite"] = make_robot_sprite(ROBOTS[mr["id"]], size=36)

    # ─── Event routing ────────────────────────────────────────────────────────
    def handle_event(self, event):
        mx, my = pygame.mouse.get_pos()

        if self.state == STATE_MENU:
            self._handle_menu_event(event, mx, my)

        elif self.state == STATE_LEVEL_SELECT:
            self._handle_level_select_event(event, mx, my)

        elif self.state == STATE_PLAYING:
            if self._gameplay:
                result = self._gameplay.handle_event(event)
                if result == STATE_PAUSED:
                    self.state = STATE_PAUSED
                elif result == STATE_WIN:
                    self._on_win()
                elif result == STATE_LOSE:
                    self.state = STATE_LOSE
                    self._result_timer = 0.0

        elif self.state == STATE_PAUSED:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.state = STATE_PLAYING
                if self._gameplay:
                    self._gameplay.paused = False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for label, rect in self._pause_buttons:
                    if rect.collidepoint(mx, my):
                        if label == "RESUME":
                            self.state = STATE_PLAYING
                            if self._gameplay:
                                self._gameplay.paused = False
                        elif label == "RESTART LEVEL":
                            self._start_level(self._selected_level)
                        elif label == "MAIN MENU":
                            self.state = STATE_MENU

        elif self.state in (STATE_WIN, STATE_LOSE):
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self._handle_end_screen_click(mx, my)

        elif self.state == STATE_HOW_TO_PLAY:
            if event.type == pygame.KEYDOWN:
                self.state = STATE_MENU
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # Back button or anywhere else
                self.state = STATE_MENU

    def _handle_menu_event(self, event, mx, my):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            cy = SCREEN_H // 2
            btn_data = [
                ("PLAY",          cy + 20),
                ("LEVEL SELECT",  cy + 75),
                ("HOW TO PLAY",   cy + 130),
                ("QUIT",          cy + 185),
            ]
            for label, by in btn_data:
                r = pygame.Rect(SCREEN_W // 2 - 110, by - 20, 220, 40)
                if r.collidepoint(mx, my):
                    if label == "PLAY":
                        first_unlocked = self._get_first_unlocked()
                        self._start_level(first_unlocked)
                    elif label == "LEVEL SELECT":
                        self.state = STATE_LEVEL_SELECT
                    elif label == "HOW TO PLAY":
                        self.state = STATE_HOW_TO_PLAY
                    elif label == "QUIT":
                        pygame.event.post(pygame.event.Event(pygame.QUIT))

    def _handle_level_select_event(self, event, mx, my):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.state = STATE_MENU
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # Back button
            back_r = pygame.Rect(20, 20, 80, 35)
            if back_r.collidepoint(mx, my):
                self.state = STATE_MENU
                return
            # Level buttons
            for lvl_id, r in self._level_buttons:
                if r.collidepoint(mx, my):
                    if lvl_id in self.save.get("unlocked_levels", [1]):
                        self._start_level(lvl_id)
                    return

    def _handle_end_screen_click(self, mx, my):
        if self.state == STATE_WIN:
            retry_r = pygame.Rect(SCREEN_W // 2 - 115, 430, 105, 38)
            next_r  = pygame.Rect(SCREEN_W // 2 + 5,   430, 105, 38)
            menu_r  = pygame.Rect(SCREEN_W // 2 - 55,  476, 110, 34)
            if retry_r.collidepoint(mx, my):
                self._start_level(self._selected_level)
            elif next_r.collidepoint(mx, my):
                nxt = min(40, self._selected_level + 1)
                self._start_level(nxt)
            elif menu_r.collidepoint(mx, my):
                self.state = STATE_MENU
        elif self.state == STATE_LOSE:
            retry_r = pygame.Rect(SCREEN_W // 2 - 110, SCREEN_H // 2 + 60, 100, 40)
            menu_r  = pygame.Rect(SCREEN_W // 2 + 10,  SCREEN_H // 2 + 60, 100, 40)
            if retry_r.collidepoint(mx, my):
                self._start_level(self._selected_level)
            elif menu_r.collidepoint(mx, my):
                self.state = STATE_MENU

    # ─── Game transitions ─────────────────────────────────────────────────────
    def _get_first_unlocked(self) -> int:
        return max(self.save.get("unlocked_levels", [1]))

    def _start_level(self, level_id: int):
        from game.gameplay import GameplayState
        self._selected_level = level_id
        self._gameplay = GameplayState(self.save)
        self._gameplay.load_level(level_id)
        self.state = STATE_PLAYING

    def _on_win(self):
        gp = self._gameplay
        self._win_score = gp.score
        self._robots_through = gp.robots_through
        # Stars: 3 = perfect, 2 = ≤2 through, 1 = any robots through
        stars = 3 if self._robots_through == 0 else (2 if self._robots_through <= 2 else 1)
        self._win_stars = stars

        # Count drones still available
        from settings import GRID_ROWS, CURRENCY_PER_STAR, CURRENCY_PER_DRONE_LEFT, CURRENCY_PERFECT_BONUS
        drones_left = sum(1 for d in gp._emergency_drones if d)
        self._drones_left = drones_left

        # Earn Nano-Credits
        earned_nc = stars * CURRENCY_PER_STAR
        earned_nc += drones_left * CURRENCY_PER_DRONE_LEFT
        if self._robots_through == 0:
            earned_nc += CURRENCY_PERFECT_BONUS
        self._earned_nc = earned_nc

        # Save progress
        unlocked = self.save.get("unlocked_levels", [1])
        next_lvl = self._selected_level + 1
        if next_lvl <= 40 and next_lvl not in unlocked:
            unlocked.append(next_lvl)
        self.save["unlocked_levels"] = unlocked
        old_stars = self.save.get("stars", {}).get(str(self._selected_level), 0)
        self.save.setdefault("stars", {})[str(self._selected_level)] = max(old_stars, stars)
        self.save.setdefault("high_scores", {})[str(self._selected_level)] = max(
            self.save.get("high_scores", {}).get(str(self._selected_level), 0),
            self._win_score
        )
        # Accumulate currency
        self.save["nano_credits"] = self.save.get("nano_credits", 0) + earned_nc
        write_save(self.save)
        self.state = STATE_WIN
        self._result_timer = 0.0
        self._drones_left = drones_left

    # ─── Update ───────────────────────────────────────────────────────────────
    def update(self, dt: float):
        self._menu_scroll += dt * 12
        self._title_glow = (math.sin(pygame.time.get_ticks() * 0.002) + 1) * 0.5

        # Menu robot walk
        for mr in self._menu_robots:
            mr["x"] += mr["speed"] * dt
            if mr["x"] > SCREEN_W + 80:
                mr["x"] = -80

        if self.state == STATE_PLAYING and self._gameplay:
            result = self._gameplay.update(dt)
            if result == STATE_WIN:
                self._on_win()
            elif result == STATE_LOSE:
                self.state = STATE_LOSE
                self._result_timer = 0.0

        if self.state in (STATE_WIN, STATE_LOSE):
            self._result_timer += dt

    # ─── Draw ─────────────────────────────────────────────────────────────────
    def draw(self, surface):
        if self.state == STATE_MENU:
            self._draw_menu(surface)
        elif self.state == STATE_LEVEL_SELECT:
            self._draw_level_select(surface)
        elif self.state == STATE_PLAYING and self._gameplay:
            self._gameplay.draw(surface)
        elif self.state == STATE_PAUSED and self._gameplay:
            self._pause_buttons = self._gameplay.draw_pause(surface)
        elif self.state == STATE_WIN:
            if self._gameplay:
                self._gameplay.draw(surface)
            self._draw_win_screen(surface)
        elif self.state == STATE_LOSE:
            if self._gameplay:
                self._gameplay.draw(surface)
            self._draw_lose_screen(surface)
        elif self.state == STATE_HOW_TO_PLAY:
            self._draw_how_to_play(surface)

    # ─── Main Menu ────────────────────────────────────────────────────────────
    def _draw_menu(self, surface):
        draw_background(surface, "night_dark", self._menu_scroll)

        # Animated title glow
        glow_r = int(180 + self._title_glow * 20)
        cx = SCREEN_W // 2
        title_y = SCREEN_H // 2 - 120
        draw_glow(surface, cx, title_y, glow_r, COLORS["neon_cyan"], intensity=0.1)

        render_text(surface, "TURRETS", cx, title_y - 28,
                     COLORS["neon_green"], size="huge", center=True)
        render_text(surface, "VS ROBOTS", cx, title_y + 30,
                     COLORS["neon_orange"], size="huge", center=True)

        # Subtitle
        render_text(surface, "Defend your Bio-Tech Garden", cx, title_y + 75,
                     COLORS["text_secondary"], size="small", center=True)

        # Buttons
        cy = SCREEN_H // 2
        btn_data = [
            ("PLAY",         cy + 20,  COLORS["neon_green"]),
            ("LEVEL SELECT", cy + 75,  COLORS["neon_cyan"]),
            ("HOW TO PLAY",  cy + 130, COLORS["text_primary"]),
            ("QUIT",         cy + 185, COLORS["neon_red"]),
        ]
        mx, my = pygame.mouse.get_pos()
        for label, by, color in btn_data:
            r = pygame.Rect(cx - 110, by - 20, 220, 40)
            hovered = r.collidepoint(mx, my)
            bg = (30, 60, 40) if hovered else COLORS["ui_panel"]
            border = color if hovered else COLORS["ui_border"]
            draw_rounded_rect(surface, r, bg, radius=8, border=2, border_color=border)
            render_text(surface, label, cx, by, color if hovered else COLORS["text_primary"],
                         size="medium", center=True)

        # Walking robots
        for mr in self._menu_robots:
            r = mr["sprite"].get_rect(center=(int(mr["x"]), int(mr["y"])))
            surface.blit(mr["sprite"], r)

        # Version + NC balance
        total_nc = self.save.get("nano_credits", 0)
        render_text(surface, f"💾 {total_nc} NC", 80, 28,
                     (255, 220, 80), size="small", center=True, shadow=True)
        render_text(surface, "v1.0  |  Use mouse to play",
                     cx, SCREEN_H - 20, COLORS["text_dim"], size="tiny", center=True)
        draw_scanline_overlay(surface)

    # ─── Level Select ─────────────────────────────────────────────────────────
    def _draw_level_select(self, surface):
        draw_background(surface, "datacenter_blue", self._menu_scroll * 0.3)
        render_text(surface, "SELECT LEVEL", SCREEN_W // 2, 40,
                     COLORS["neon_cyan"], size="large", center=True)

        # Back button
        back_r = pygame.Rect(20, 20, 80, 35)
        mx, my = pygame.mouse.get_pos()
        draw_rounded_rect(surface, back_r, COLORS["ui_panel"], radius=6,
                           border=1, border_color=COLORS["ui_border"])
        render_text(surface, "< BACK", 60, 37, COLORS["text_primary"], size="small", center=True)

        unlocked = self.save.get("unlocked_levels", [1])
        stars_map = self.save.get("stars", {})
        self._level_buttons = []

        worlds = {1: "Outer Perimeter", 2: "Neon Marshlands",
                   3: "Ruined Data Center", 4: "Orbital Platform", 5: "The Core"}
        world_colors = {1: COLORS["neon_orange"], 2: COLORS["neon_cyan"],
                         3: COLORS["neon_blue"], 4: COLORS["neon_purple"], 5: COLORS["neon_red"]}

        WORLDS = 5
        LEVELS_PER_WORLD = 8
        panel_w = SCREEN_W // WORLDS - 10
        panel_x = 5

        for w in range(1, WORLDS + 1):
            wcolor = world_colors[w]
            panel_rect = pygame.Rect(panel_x, 70, panel_w, SCREEN_H - 100)
            draw_rounded_rect(surface, panel_rect, (15, 20, 35), radius=8,
                               border=1, border_color=wcolor)
            render_text(surface, f"W{w}", panel_x + panel_w // 2, 90,
                         wcolor, size="small", center=True)
            render_text(surface, worlds[w][:12], panel_x + panel_w // 2, 108,
                         COLORS["text_secondary"], size="tiny", center=True)

            for i in range(LEVELS_PER_WORLD):
                lvl_id = (w - 1) * LEVELS_PER_WORLD + i + 1
                lx = panel_x + (i % 2) * (panel_w // 2)
                ly = 130 + (i // 2) * 55
                btn_r = pygame.Rect(lx + 4, ly, panel_w // 2 - 8, 46)
                self._level_buttons.append((lvl_id, btn_r))

                is_unlocked = lvl_id in unlocked
                is_hovered = btn_r.collidepoint(mx, my)
                bg = (35, 55, 35) if (is_unlocked and is_hovered) else (
                    (20, 30, 50) if is_unlocked else (15, 15, 20))
                border = wcolor if (is_unlocked and is_hovered) else (
                    COLORS["ui_border"] if is_unlocked else COLORS["text_dim"])
                draw_rounded_rect(surface, btn_r, bg, radius=6, border=1, border_color=border)

                if is_unlocked:
                    render_text(surface, str(lvl_id), btn_r.centerx, btn_r.centery - 6,
                                 COLORS["text_primary"], size="small", center=True)
                    # Stars
                    s = stars_map.get(str(lvl_id), 0)
                    for si in range(3):
                        sc = wcolor if si < s else COLORS["text_dim"]
                        pygame.draw.circle(surface, sc,
                                            (btn_r.centerx - 10 + si * 10, btn_r.bottom - 10), 4)
                else:
                    render_text(surface, "🔒", btn_r.centerx, btn_r.centery,
                                 COLORS["text_dim"], size="small", center=True, shadow=False)
            panel_x += panel_w + 5

        draw_scanline_overlay(surface)

    # ─── Win Screen ───────────────────────────────────────────────────────────
    def _draw_win_screen(self, surface):
        from settings import CURRENCY_PER_STAR, CURRENCY_PER_DRONE_LEFT, CURRENCY_PERFECT_BONUS, GRID_ROWS
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 18, 0, 170))
        surface.blit(overlay, (0, 0))

        cx = SCREEN_W // 2
        anim = min(1.0, self._result_timer * 1.5)

        # Title glow
        draw_glow(surface, cx, 90, int(140 * anim), COLORS["neon_green"], intensity=0.35)
        render_text(surface, "SECTOR SECURED", cx, 80,
                     COLORS["neon_green"], size="huge", center=True)

        # ── Stars ──────────────────────────────────────────────────────────────
        star_y = 148
        for i in range(3):
            earned = i < self._win_stars
            sx = cx - 70 + i * 70
            if earned:
                draw_glow(surface, sx, star_y, 28, COLORS["neon_yellow"], intensity=0.6)
                # 5-point star
                self._draw_star(surface, sx, star_y, 20, COLORS["neon_yellow"])
            else:
                self._draw_star(surface, sx, star_y, 18, COLORS["text_dim"], filled=False)

        # ── Currency breakdown panel ────────────────────────────────────────
        panel_w, panel_h = 420, 180
        panel_x = cx - panel_w // 2
        panel_y = 185
        panel_rect = pygame.Rect(panel_x, panel_y, panel_w, panel_h)
        draw_rounded_rect(surface, panel_rect, (10, 28, 10), radius=10,
                           border=2, border_color=COLORS["neon_green"])

        # Panel title
        render_text(surface, "NANO-CREDITS EARNED", cx, panel_y + 18,
                     COLORS["neon_cyan"], size="small", center=True)

        nc_col = (255, 220, 80)
        row_y = panel_y + 42
        row_gap = 26

        # Stars row
        star_nc = self._win_stars * CURRENCY_PER_STAR
        self._draw_nc_row(surface, panel_x + 20, row_y, panel_w - 40,
                           f"⭐ {self._win_stars} Stars × {CURRENCY_PER_STAR}",
                           f"+{star_nc} NC", nc_col)
        row_y += row_gap

        # Drones row
        drone_nc = self._drones_left * CURRENCY_PER_DRONE_LEFT
        self._draw_nc_row(surface, panel_x + 20, row_y, panel_w - 40,
                           f"⚡ {self._drones_left} Drones saved × {CURRENCY_PER_DRONE_LEFT}",
                           f"+{drone_nc} NC", COLORS["drone_color"])
        row_y += row_gap

        # Perfect bonus
        if self._robots_through == 0:
            self._draw_nc_row(surface, panel_x + 20, row_y, panel_w - 40,
                               "🏆 Perfect Defence Bonus",
                               f"+{CURRENCY_PERFECT_BONUS} NC", COLORS["neon_purple"])
            row_y += row_gap

        # Divider
        pygame.draw.line(surface, COLORS["ui_border"],
                          (panel_x + 16, row_y + 4), (panel_x + panel_w - 16, row_y + 4), 1)
        row_y += 12

        # Total
        total_nc = self.save.get("nano_credits", 0)
        self._draw_nc_row(surface, panel_x + 20, row_y, panel_w - 40,
                           f"TOTAL NC (all levels):",
                           f"{total_nc} NC", nc_col)

        # Big earned number floating in
        earn_y = panel_y + panel_h + 18
        draw_glow(surface, cx, earn_y, 50, nc_col, intensity=0.3 * anim)
        render_text(surface, f"+{self._earned_nc} NC", cx, earn_y,
                     nc_col, size="large", center=True)

        # ── Buttons ────────────────────────────────────────────────────────────
        btn_y = earn_y + 48
        mx2, my2 = pygame.mouse.get_pos()
        for label, bx, color in [
            ("RETRY",    cx - 115, COLORS["text_secondary"]),
            ("NEXT LVL", cx + 5,   COLORS["neon_green"]),
        ]:
            r = pygame.Rect(bx, btn_y, 105, 38)
            hov = r.collidepoint(mx2, my2)
            draw_rounded_rect(surface, r,
                               (20, 55, 20) if hov else COLORS["ui_panel"],
                               radius=8, border=2,
                               border_color=color if hov else COLORS["ui_border"])
            render_text(surface, label, r.centerx, r.centery, color, size="small", center=True)

        menu_r = pygame.Rect(cx - 55, btn_y + 46, 110, 34)
        hov = menu_r.collidepoint(mx2, my2)
        draw_rounded_rect(surface, menu_r, COLORS["ui_panel"], radius=6,
                           border=1, border_color=COLORS["ui_border"])
        render_text(surface, "MAIN MENU", cx, btn_y + 63,
                     COLORS["text_secondary"], size="small", center=True)

    def _draw_star(self, surface, cx, cy, r, color, filled=True):
        """Draw a 5-pointed star."""
        pts = []
        for i in range(10):
            angle = math.radians(i * 36 - 90)
            radius = r if i % 2 == 0 else r * 0.42
            pts.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
        if filled:
            pygame.draw.polygon(surface, color, pts)
        else:
            pygame.draw.polygon(surface, color, pts, 2)

    def _draw_nc_row(self, surface, x, y, w, left_text, right_text, right_color):
        """Draw one row of the NC breakdown with left label and right value."""
        render_text(surface, left_text, x, y, COLORS["text_secondary"], size="tiny",
                     center=False, shadow=False)
        render_text(surface, right_text, x + w, y, right_color, size="tiny",
                     center=False, shadow=False)

    # ─── Lose Screen ──────────────────────────────────────────────────────────
    def _draw_lose_screen(self, surface):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        flicker = abs(math.sin(self._result_timer * 8)) * 60
        overlay.fill((40 + int(flicker), 0, 0, 150))
        surface.blit(overlay, (0, 0))

        cx = SCREEN_W // 2
        draw_glow(surface, cx, SCREEN_H // 2 - 60, 200, COLORS["neon_red"],
                   intensity=min(0.5, self._result_timer * 0.5))

        render_text(surface, "BASE COMPROMISED", cx, SCREEN_H // 2 - 90,
                     COLORS["neon_red"], size="huge", center=True)
        render_text(surface, "5 robots breached your defenses.",
                     cx, SCREEN_H // 2 - 20, COLORS["text_secondary"], size="small", center=True)

        for label, rx, color in [
            ("RETRY",  cx - 55, COLORS["neon_orange"]),
            ("MENU",   cx + 55, COLORS["text_secondary"]),
        ]:
            r = pygame.Rect(rx - 45, SCREEN_H // 2 + 60, 90, 40)
            mx2, my2 = pygame.mouse.get_pos()
            hov = r.collidepoint(mx2, my2)
            draw_rounded_rect(surface, r, (60, 20, 10) if hov else COLORS["ui_panel"],
                               radius=8, border=2, border_color=color)
            render_text(surface, label, rx, SCREEN_H // 2 + 80, color, size="small", center=True)

    # ─── How To Play ──────────────────────────────────────────────────────────
    def _draw_how_to_play(self, surface):
        draw_background(surface, "datacenter_blue", self._menu_scroll * 0.2)

        cx = SCREEN_W // 2
        render_text(surface, "HOW TO PLAY", cx, 32, COLORS["neon_cyan"], size="large", center=True)

        # ── Panel layout: 3 columns ──────────────────────────────────────────
        panels = [
            {
                "title": "⚡  ENERGY",
                "color": COLORS["neon_yellow"],
                "x": 80, "y": 90, "w": 290, "h": 200,
                "lines": [
                    "Energy Cores power everything.",
                    "",
                    "• Place Generators on the grid",
                    "  to earn cores over time.",
                    "• Yellow cores also fall from",
                    "  the sky — click to collect!",
                    "• Cores fade after 10 seconds",
                    "  so grab them quickly.",
                    "• More generators = more power.",
                ],
            },
            {
                "title": "🔧  PLACING TURRETS",
                "color": COLORS["neon_green"],
                "x": 405, "y": 90, "w": 290, "h": 200,
                "lines": [
                    "Click a card → click a grid cell.",
                    "",
                    "• Green cards = you can afford it.",
                    "• Grey cards = not enough energy.",
                    "• Cards recharge after use",
                    "  (watch the fill bar).",
                    "• Shovel button (bottom-right)",
                    "  sells a turret for 50% back.",
                    "• Right-click cancels selection.",
                ],
            },
            {
                "title": "🤖  ROBOTS",
                "color": COLORS["neon_red"],
                "x": 730, "y": 90, "w": 290, "h": 200,
                "lines": [
                    "Robots march left across lanes.",
                    "",
                    "• They MUST physically reach",
                    "  a turret to damage it.",
                    "• Block every lane or they",
                    "  walk straight through!",
                    "• HP bar appears when hurt.",
                    "• 5 robots through = GAME OVER.",
                    "• Kill them before they arrive.",
                ],
            },
            {
                "title": "⚡  EMERGENCY DRONES",
                "color": COLORS["drone_color"],
                "x": 80, "y": 315, "w": 290, "h": 170,
                "lines": [
                    "Each lane has ONE drone.",
                    "",
                    "• If a robot slips through,",
                    "  the drone auto-deploys and",
                    "  sweeps the entire lane.",
                    "• ⚡ icon = drone ready.",
                    "• ✗ icon = drone spent.",
                    "  Guard those lanes carefully!",
                ],
            },
            {
                "title": "🌊  WAVES",
                "color": COLORS["wave_color"],
                "x": 405, "y": 315, "w": 290, "h": 170,
                "lines": [
                    "Robots arrive in timed waves.",
                    "",
                    "• Wait for the countdown OR",
                    "  press SPACE to start early",
                    "  and earn bonus time to build.",
                    "• Each level has a fixed number",
                    "  of waves shown in the HUD.",
                    "• Last wave is always a boss!",
                ],
            },
            {
                "title": "⌨️  CONTROLS",
                "color": COLORS["neon_purple"],
                "x": 730, "y": 315, "w": 290, "h": 170,
                "lines": [
                    "SPACE  — start next wave early",
                    "ESC    — pause / resume",
                    "R      — restart level",
                    "",
                    "Mouse:",
                    "Left-click  — place / collect",
                    "Right-click — cancel placement",
                    "Shovel mode — sell a turret",
                ],
            },
        ]

        mx, my = pygame.mouse.get_pos()
        for p in panels:
            r = pygame.Rect(p["x"], p["y"], p["w"], p["h"])
            draw_rounded_rect(surface, r, (12, 20, 38), radius=10,
                               border=2, border_color=p["color"])

            # Title bar
            title_r = pygame.Rect(p["x"], p["y"], p["w"], 30)
            draw_rounded_rect(surface, title_r,
                               tuple(c // 4 for c in p["color"]), radius=10)
            render_text(surface, p["title"], p["x"] + p["w"] // 2, p["y"] + 15,
                         p["color"], size="small", center=True)

            for i, line in enumerate(p["lines"]):
                color = COLORS["text_secondary"] if line.startswith("•") else COLORS["text_primary"]
                if line == "":
                    continue
                render_text(surface, line, p["x"] + 12, p["y"] + 38 + i * 16,
                             color, size="tiny", center=False, shadow=False)

        # TIP banner
        tip_r = pygame.Rect(80, 505, 940, 38)
        draw_rounded_rect(surface, tip_r, (20, 40, 20), radius=8,
                           border=1, border_color=COLORS["neon_green"])
        render_text(surface, "💡 TIP: Start with a Generator in the middle rows, then cover ALL lanes with Pulse Turrets before spending on upgrades.",
                     cx, 524, COLORS["neon_green"], size="tiny", center=True, shadow=False)

        # Back button
        back_r = pygame.Rect(cx - 80, SCREEN_H - 52, 160, 38)
        hov = back_r.collidepoint(mx, my)
        draw_rounded_rect(surface, back_r,
                           (30, 50, 80) if hov else COLORS["ui_panel"],
                           radius=8, border=2,
                           border_color=COLORS["neon_cyan"] if hov else COLORS["ui_border"])
        render_text(surface, "< BACK TO MENU", cx, SCREEN_H - 33,
                     COLORS["neon_cyan"] if hov else COLORS["text_secondary"],
                     size="small", center=True)

        draw_scanline_overlay(surface)
