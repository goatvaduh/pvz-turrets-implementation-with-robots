"""
game/ui.py — HUD, turret card bar, energy display, wave counter, tooltips, popups.
"""

import math
import pygame
from settings import (COLORS, SCREEN_W, SCREEN_H, HUD_TOP_H, HUD_BOT_H,
                       GRID_OFFSET_X, GRID_OFFSET_Y, CELL_W, CELL_H,
                       GRID_COLS, GRID_ROWS, CARD_BAR_SLOTS, ENERGY_CORE_RADIUS)
from utils.helpers import (render_text, draw_rounded_rect, draw_glow, get_font,
                             clamp)
from utils.draw_sprites import make_turret_sprite, draw_energy_core
from data.turrets_data import TURRETS, GENERATORS


CARD_W = 72
CARD_H = 88
CARD_PAD = 6
CARDS_START_X = 10
CARDS_Y = SCREEN_H - HUD_BOT_H + 11


class TurretCard:
    """A single selectable turret card in the bottom bar."""

    SPRITE_CACHE = {}

    def __init__(self, turret_id: str, index: int):
        self.turret_id = turret_id
        self.index = index

        data = TURRETS.get(turret_id) or GENERATORS.get(turret_id)
        self.name = data["name"]
        self.cost = data["cost"]
        self.color = data["color"]
        self.recharge = data["recharge"]
        self.tier = data.get("tier", 1)

        self.x = CARDS_START_X + index * (CARD_W + CARD_PAD)
        self.y = CARDS_Y
        self.rect = pygame.Rect(self.x, self.y, CARD_W, CARD_H)
        self.selected = False
        self.hovered = False

        if turret_id not in TurretCard.SPRITE_CACHE:
            TurretCard.SPRITE_CACHE[turret_id] = make_turret_sprite(data, size=38)
        self.sprite = TurretCard.SPRITE_CACHE[turret_id]

    def can_afford(self, energy: int) -> bool:
        return energy >= self.cost

    def draw(self, surface, energy: int, cooldown_frac: float = 1.0):
        affordable = self.can_afford(energy)

        # Card background
        if self.selected:
            bg_color = (40, 70, 120)
            border_color = COLORS["neon_cyan"]
        elif self.hovered:
            bg_color = (30, 50, 90)
            border_color = COLORS["ui_border_hi"]
        elif not affordable:
            bg_color = (20, 22, 30)
            border_color = COLORS["text_dim"]
        else:
            bg_color = COLORS["card_bg"]
            border_color = COLORS["card_border"]

        draw_rounded_rect(surface, self.rect, bg_color, radius=6)
        draw_rounded_rect(surface, self.rect, (0, 0, 0, 0), radius=6,
                           border=2, border_color=border_color)

        # Cooldown overlay
        if cooldown_frac < 1.0:
            overlay = pygame.Surface((CARD_W, CARD_H), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, int(180 * (1 - cooldown_frac))))
            overlay_rect = pygame.Rect(0, 0, CARD_W, CARD_H)
            pygame.draw.rect(overlay, (0, 0, 0, 0), overlay_rect, border_radius=6)
            surface.blit(overlay, self.rect.topleft)

            # Fill bar from bottom
            fill_h = int(CARD_H * cooldown_frac)
            bar_surf = pygame.Surface((CARD_W - 4, fill_h), pygame.SRCALPHA)
            bar_surf.fill((*self.color, 60))
            surface.blit(bar_surf, (self.x + 2, self.y + CARD_H - fill_h - 2))

        # Sprite (greyed out if unaffordable)
        spr = self.sprite.copy()
        if not affordable:
            grey = pygame.Surface(spr.get_size(), pygame.SRCALPHA)
            grey.fill((0, 0, 0, 140))
            spr.blit(grey, (0, 0))
        cx = self.x + CARD_W // 2
        sprite_r = spr.get_rect(center=(cx, self.y + 26))
        surface.blit(spr, sprite_r)

        # Cost
        cost_color = COLORS["card_afford"] if affordable else COLORS["card_cant"]
        cost_str = str(self.cost)
        render_text(surface, cost_str, cx, self.y + CARD_H - 22,
                     cost_color, size="small", center=True)

        # Name (very small, truncated)
        short_name = self.name[:9]
        render_text(surface, short_name, cx, self.y + CARD_H - 11,
                     COLORS["text_secondary"], size="tiny", center=True)

        # Tier dots
        for ti in range(self.tier):
            dot_x = self.x + 5 + ti * 6
            pygame.draw.circle(surface, self.color, (dot_x, self.y + 5), 2)

        # Glow when selected
        if self.selected:
            draw_glow(surface, cx, self.y + CARD_H // 2, CARD_W // 2 + 4,
                       COLORS["neon_cyan"], intensity=0.15)


class HUD:
    """The full in-game HUD: top bar, bottom card bar, tooltips, shovel."""

    def __init__(self):
        self.cards: list[TurretCard] = []
        self.selected_index: int = -1
        self.shovel_active = False
        self.shovel_rect = pygame.Rect(SCREEN_W - 80, SCREEN_H - HUD_BOT_H + 10, 70, 88)
        self._tooltip_turret_id = None
        self._tooltip_pos = (0, 0)
        self.scroll_offset = 0
        self._total_cards: list[str] = []
        self._cooldowns: dict = {}
        # Touch swipe tracking for card bar
        self._swipe_start_x: int | None = None
        self._swipe_start_offset: int = 0
        self._swipe_threshold = 35       # px drag before we count as a swipe

    def setup_cards(self, available_turret_ids: list, cooldowns: dict = None):
        """Populate card bar with available turrets for this level."""
        self._total_cards = list(available_turret_ids)
        self._cooldowns = cooldowns or {}
        self._rebuild_cards()

    def _rebuild_cards(self):
        visible = self._total_cards[self.scroll_offset:self.scroll_offset + CARD_BAR_SLOTS]
        self.cards = [TurretCard(tid, i) for i, tid in enumerate(visible)]
        if self.selected_index >= len(self.cards):
            self.selected_index = -1

    def scroll_left(self):
        self.scroll_offset = max(0, self.scroll_offset - 1)
        self._rebuild_cards()

    def scroll_right(self):
        self.scroll_offset = min(len(self._total_cards) - CARD_BAR_SLOTS,
                                  self.scroll_offset + 1)
        self._rebuild_cards()

    def get_selected_id(self) -> str | None:
        if 0 <= self.selected_index < len(self.cards):
            return self.cards[self.selected_index].turret_id
        return None

    def deselect(self):
        self.selected_index = -1
        self.shovel_active = False
        for c in self.cards:
            c.selected = False

    def handle_touch_drag(self, mx: int, my: int):
        """Called on MOUSEMOTION while touch is active — detects swipe on card bar."""
        bar_rect = pygame.Rect(0, SCREEN_H - HUD_BOT_H, SCREEN_W - 85, HUD_BOT_H)
        if not bar_rect.collidepoint(mx, my):
            self._swipe_start_x = None
            return
        if self._swipe_start_x is None:
            self._swipe_start_x = mx
            self._swipe_start_offset = self.scroll_offset
            return
        dx = self._swipe_start_x - mx
        cards_scrolled = int(dx / (CARD_W + CARD_PAD))
        new_off = clamp(self._swipe_start_offset + cards_scrolled,
                         0, max(0, len(self._total_cards) - CARD_BAR_SLOTS))
        if new_off != self.scroll_offset:
            self.scroll_offset = new_off
            self._rebuild_cards()

    def handle_click(self, mx, my, energy: int) -> str | None:
        """Handle click on a card or shovel. Returns selected turret_id or 'shovel'."""
        # Shovel
        if self.shovel_rect.collidepoint(mx, my):
            self.shovel_active = not self.shovel_active
            self.selected_index = -1
            for c in self.cards:
                c.selected = False
            return "shovel" if self.shovel_active else None

        # Scroll arrows
        left_arrow = pygame.Rect(CARDS_START_X - 22, CARDS_Y, 18, CARD_H)
        right_arrow = pygame.Rect(CARDS_START_X + CARD_BAR_SLOTS * (CARD_W + CARD_PAD) + 4,
                                    CARDS_Y, 18, CARD_H)
        if left_arrow.collidepoint(mx, my):
            self.scroll_left()
            return None
        if right_arrow.collidepoint(mx, my):
            self.scroll_right()
            return None

        for i, card in enumerate(self.cards):
            if card.rect.collidepoint(mx, my):
                if not card.can_afford(energy):
                    return None
                cd = self._cooldowns.get(card.turret_id)
                if cd and not cd.ready():
                    return None
                # Toggle selection
                if self.selected_index == i:
                    self.deselect()
                    return None
                else:
                    self.selected_index = i
                    self.shovel_active = False
                    for j, c in enumerate(self.cards):
                        c.selected = (j == i)
                    return card.turret_id
        return None

    def handle_hover(self, mx, my):
        """Update hover states and tooltip."""
        self._tooltip_turret_id = None
        for card in self.cards:
            card.hovered = card.rect.collidepoint(mx, my)
            if card.hovered:
                self._tooltip_turret_id = card.turret_id
                self._tooltip_pos = (mx, my)

    def draw(self, surface, energy: int, wave_num: int, total_waves: int,
              next_wave_countdown: float, level_name: str, score: int):
        """Draw the full HUD."""
        w = SCREEN_W

        # ── Top bar ──────────────────────────────────────────────────────────
        top_rect = pygame.Rect(0, 0, w, HUD_TOP_H)
        draw_rounded_rect(surface, top_rect, COLORS["ui_panel"], radius=0)
        pygame.draw.line(surface, COLORS["ui_border"], (0, HUD_TOP_H - 1), (w, HUD_TOP_H - 1), 1)

        # Energy display
        draw_energy_core(surface, 28, HUD_TOP_H // 2, ENERGY_CORE_RADIUS - 2)
        render_text(surface, str(energy), 48, HUD_TOP_H // 2,
                     COLORS["energy_color"], size="medium", center=False)

        # Level name
        render_text(surface, level_name, w // 2, HUD_TOP_H // 2,
                     COLORS["text_primary"], size="medium", center=True)

        # Wave counter
        wave_str = f"WAVE {wave_num}/{total_waves}"
        render_text(surface, wave_str, w // 2 + 200, HUD_TOP_H // 2,
                     COLORS["wave_color"], size="medium", center=True)

        # Next wave countdown
        if next_wave_countdown > 0:
            cd_str = f"NEXT: {next_wave_countdown:.0f}s"
            render_text(surface, cd_str, w // 2 + 360, HUD_TOP_H // 2,
                         COLORS["text_secondary"], size="small", center=True)
        elif next_wave_countdown == 0:
            render_text(surface, "[ SPACE ] START", w // 2 + 360, HUD_TOP_H // 2,
                         COLORS["neon_green"], size="small", center=True)

        # Score
        render_text(surface, f"SCORE: {score}", w - 110, HUD_TOP_H // 2,
                     COLORS["text_secondary"], size="small", center=True)

        # ── Bottom bar ───────────────────────────────────────────────────────
        bot_rect = pygame.Rect(0, SCREEN_H - HUD_BOT_H, w, HUD_BOT_H)
        draw_rounded_rect(surface, bot_rect, COLORS["ui_panel"], radius=0)
        pygame.draw.line(surface, COLORS["ui_border"],
                          (0, SCREEN_H - HUD_BOT_H), (w, SCREEN_H - HUD_BOT_H), 1)

        # Scroll arrows
        if self.scroll_offset > 0:
            ax = CARDS_START_X - 15
            ay = CARDS_Y + CARD_H // 2
            pygame.draw.polygon(surface, COLORS["text_secondary"],
                                  [(ax + 8, ay - 8), (ax, ay), (ax + 8, ay + 8)])
        if self.scroll_offset + CARD_BAR_SLOTS < len(self._total_cards):
            ax = CARDS_START_X + CARD_BAR_SLOTS * (CARD_W + CARD_PAD) + 8
            ay = CARDS_Y + CARD_H // 2
            pygame.draw.polygon(surface, COLORS["text_secondary"],
                                  [(ax, ay - 8), (ax + 8, ay), (ax, ay + 8)])

        # Cards
        for card in self.cards:
            cd = self._cooldowns.get(card.turret_id)
            frac = cd.fraction() if cd else 1.0
            card.draw(surface, energy, frac)

        # Shovel button
        shovel_color = COLORS["sell_color"] if self.shovel_active else COLORS["ui_border"]
        draw_rounded_rect(surface, self.shovel_rect,
                           (50, 40, 10) if self.shovel_active else (20, 25, 35),
                           radius=6, border=2, border_color=shovel_color)
        render_text(surface, "🔧", self.shovel_rect.centerx, self.shovel_rect.centery - 10,
                     shovel_color, size="large", center=True, shadow=False)
        render_text(surface, "SELL", self.shovel_rect.centerx, self.shovel_rect.bottom - 16,
                     shovel_color, size="tiny", center=True)

        # ── Tooltip ──────────────────────────────────────────────────────────
        if self._tooltip_turret_id:
            self._draw_tooltip(surface, self._tooltip_turret_id, self._tooltip_pos)

    def _draw_tooltip(self, surface, turret_id, pos):
        data = TURRETS.get(turret_id) or GENERATORS.get(turret_id)
        if not data:
            return

        lines = [
            data["name"],
            f"Cost: {data['cost']}  Recharge: {data.get('recharge', 0):.1f}s",
        ]
        if data.get("damage", 0) > 0:
            lines.append(f"DMG: {data['damage']}  Rate: {data.get('fire_rate', 0):.1f}/s")
        if data.get("range", 0) > 0:
            lines.append(f"Range: {data['range']} cells")
        if data.get("special"):
            lines.append(f"SPECIAL: {data['special']}")
        lines.append(data.get("description", ""))

        font_s = get_font("small")
        font_t = get_font("tiny")
        padding = 8
        line_h = 16
        tw = max(font_s.size(l)[0] for l in lines) + padding * 2
        th = len(lines) * line_h + padding * 2

        tx = clamp(pos[0] - tw // 2, 5, SCREEN_W - tw - 5)
        ty = SCREEN_H - HUD_BOT_H - th - 8

        tt_rect = pygame.Rect(tx, ty, tw, th)
        draw_rounded_rect(surface, tt_rect, COLORS["ui_panel"], radius=6,
                           border=1, border_color=data["color"])

        for i, line in enumerate(lines):
            color = data["color"] if i == 0 else COLORS["text_secondary"]
            f = font_s if i <= 1 else font_t
            txt_surf = f.render(line, True, color)
            surface.blit(txt_surf, (tx + padding, ty + padding + i * line_h))


def draw_pause_overlay(surface):
    """Semi-transparent pause overlay."""
    overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    surface.blit(overlay, (0, 0))

    render_text(surface, "PAUSED", SCREEN_W // 2, SCREEN_H // 2 - 80,
                 COLORS["neon_cyan"], size="huge", center=True)

    buttons = [
        ("RESUME", SCREEN_W // 2, SCREEN_H // 2),
        ("RESTART LEVEL", SCREEN_W // 2, SCREEN_H // 2 + 55),
        ("MAIN MENU", SCREEN_W // 2, SCREEN_H // 2 + 110),
    ]
    rects = []
    for label, bx, by in buttons:
        r = pygame.Rect(bx - 100, by - 18, 200, 36)
        draw_rounded_rect(surface, r, COLORS["ui_panel"], radius=8,
                           border=1, border_color=COLORS["ui_border_hi"])
        render_text(surface, label, bx, by, COLORS["text_primary"], size="medium", center=True)
        rects.append((label, r))
    return rects


def draw_robot_breach_warning(surface, count, max_count):
    """Top-left warning showing how many robots got through."""
    for i in range(max_count):
        c = COLORS["neon_red"] if i < count else COLORS["text_dim"]
        pygame.draw.rect(surface, c, (10 + i * 14, 4, 10, 8), border_radius=2)
