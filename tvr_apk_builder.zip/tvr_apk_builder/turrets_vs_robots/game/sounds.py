# game/sounds.py — Sound effects dictionary populated at runtime if numpy is available.
SOUNDS = {}
