"""
game/turret.py — Turret and Generator classes.
All turret types are data-driven instances. Specials are handled by checking turret.special.
"""

import math
import random
import pygame
from settings import (COLORS, CELL_W, CELL_H, GRID_ROWS, GRID_OFFSET_X, GRID_OFFSET_Y,
                       GRID_COLS)
from utils.helpers import Cooldown, dist, clamp, draw_hp_bar, draw_glow, grid_to_pixel
from utils.draw_sprites import make_turret_sprite, draw_shield_barrier
from data.turrets_data import TURRETS, GENERATORS
from game.particle import ParticleSystem
from game.projectile import (Projectile, ExplosionProjectile, SonicWaveProjectile,
                                ChainLightningProjectile, OmegaBeamProjectile)


class Turret:
    """A placed turret on the grid. Handles targeting, firing, and special abilities."""

    SPRITE_CACHE = {}

    def __init__(self, turret_id: str, col: int, row: int):
        data = TURRETS[turret_id]
        self.id = turret_id
        self.name = data["name"]
        self.col = col
        self.row = row
        x, y = grid_to_pixel(col, row)
        self.x = float(x)
        self.y = float(y)

        self.max_hp = data["hp"]
        self.hp = float(self.max_hp)
        self.damage = data["damage"]
        self.fire_rate = data["fire_rate"]    # shots per second
        self.range_cells = data["range"]
        self.proj_type = data["projectile_type"]
        self.special = data.get("special")
        self.targeting = data.get("targeting", "first")
        self.color = data["color"]
        self.cost = data["cost"]
        self.tier = data.get("tier", 1)

        self.alive = True
        self.fire_timer = Cooldown(1.0 / max(0.01, self.fire_rate), ready=True)
        self.stun_timer = 0.0
        self.damage_boost = 1.0    # from adjacent fusion reactor
        self.fire_rate_boost = 1.0 # from overclock effect

        # Special state
        self.shield_active = False
        self.shield_timer = 0.0
        self.shield_blocked = False
        self._overcharge_timer = 0.0
        self._overcharge_max = 20.0
        self._omega_timer = 0.0
        self._omega_max = 60.0
        self._time_dist_timer = 0.0
        self._time_dist_cd = 30.0
        self._replicator_timer = 0.0
        self._replicator_done = False
        self.orbit_angle = 0.0      # for nano_swarm
        self.rotation = 0.0         # visual rotation
        self.radius = 18

        # Spike launcher: passive, tracks robot passage
        self._passive_targets = set()

        # Mirror tower: remembers recent damage
        self._reflect_damage_ready = True

        if turret_id not in Turret.SPRITE_CACHE:
            Turret.SPRITE_CACHE[turret_id] = make_turret_sprite(data, size=44)
        self.sprite = Turret.SPRITE_CACHE[turret_id]

    # ─── Damage ───────────────────────────────────────────────────────────────
    def take_damage(self, amount):
        self.hp -= amount
        if self.hp <= 0:
            self.hp = 0
            self.alive = False

    def stun(self, duration):
        self.stun_timer = max(self.stun_timer, duration)

    # ─── Targeting ────────────────────────────────────────────────────────────
    def get_range_px(self, grid_range_penalty=0):
        effective_cells = max(1, self.range_cells - grid_range_penalty)
        return effective_cells * CELL_W

    def _get_targets(self, robots, range_px):
        """Return eligible robots within range, sorted by targeting mode."""
        in_range = []
        for robot in robots:
            if not robot.alive:
                continue
            if robot.is_stealth and self.id == "pulse_turret":
                continue  # pulse can't hit stealth
            if self.targeting in ("first", "lowest_hp"):
                if robot.row != self.row:
                    continue
            d = dist(self.x, self.y, robot.x, robot.y)
            if d <= range_px:
                in_range.append(robot)

        if not in_range:
            return []

        if self.targeting == "first":
            # Closest to home base (smallest x)
            return [min(in_range, key=lambda r: r.x)]
        elif self.targeting == "lowest_hp":
            return [min(in_range, key=lambda r: r.hp)]
        elif self.targeting == "all_lanes":
            return in_range
        elif self.targeting == "area":
            return in_range
        elif self.targeting == "all":
            return in_range
        else:
            return [min(in_range, key=lambda r: r.x)] if in_range else []

    # ─── Update ───────────────────────────────────────────────────────────────
    def update(self, dt, robots, projectiles: list, particles: ParticleSystem,
                grid=None, all_turrets=None):
        if not self.alive:
            return []
        new_turrets_to_place = []   # for replicator

        # Stun
        if self.stun_timer > 0:
            self.stun_timer -= dt
            return new_turrets_to_place

        # EMF zone: halve fire rate if in EMF cell
        emf_penalty = 0
        if grid and grid.emf_affected(self.col, self.row):
            emf_penalty = 1   # doubles cooldown

        range_penalty = grid.range_penalty() if grid else 0
        range_px = self.get_range_px(range_penalty)

        # Effective fire cooldown
        base_cd = 1.0 / max(0.01, self.fire_rate * self.fire_rate_boost)
        if emf_penalty:
            base_cd *= 2
        if self.fire_timer.duration != base_cd:
            self.fire_timer.duration = base_cd
        self.fire_timer.update(dt)

        # Visual rotation
        self.rotation += dt * 30
        self.orbit_angle += dt * 120   # for nano_swarm orbit

        # ── Special passive/area behaviors ──────────────────────────────────

        if self.special == "barrier":
            # Shield node: block first robot in lane
            for robot in robots:
                if not robot.alive or robot.row != self.row:
                    continue
                d = dist(self.x, self.y, robot.x, robot.y)
                if d < CELL_W and not self.shield_blocked:
                    robot.apply_stun(3.0)
                    self.shield_blocked = True
                    particles.emit_burst(int(self.x), int(self.y),
                                          COLORS["neon_blue"], count=10, speed=50, size=3, lifetime=0.4)
            return new_turrets_to_place

        if self.special == "passive_damage":
            # Spike launcher: damage all robots that walk through this cell
            for robot in robots:
                if not robot.alive:
                    continue
                d = dist(self.x, self.y, robot.x, robot.y)
                if d < CELL_W * 0.6:
                    if robot not in self._passive_targets:
                        self._passive_targets.add(robot)
                        robot.take_damage(self.damage, self)
                        particles.emit_spark(int(self.x), int(self.y),
                                              self.color, count=5)
                else:
                    self._passive_targets.discard(robot)
            return new_turrets_to_place

        if self.special == "orbit_damage":
            # Nano swarm: damage robots in adjacent cells
            for robot in robots:
                if not robot.alive:
                    continue
                d = dist(self.x, self.y, robot.x, robot.y)
                if d < CELL_W * 1.2:
                    robot.take_damage(self.damage * dt, self)
                    if random.random() < 0.1:
                        particles.emit_spark(int(robot.x), int(robot.y),
                                              self.color, count=3)
            return new_turrets_to_place

        if self.special == "pull_all_lanes":
            # Gravity well: pull all robots toward self
            for robot in robots:
                if not robot.alive:
                    continue
                d = dist(self.x, self.y, robot.x, robot.y)
                if d < range_px:
                    pull = min(CELL_W * 0.3, 30) * dt
                    dx = self.x - robot.x
                    dy = self.y - robot.y
                    mag = max(1, math.sqrt(dx * dx + dy * dy))
                    robot.x += (dx / mag) * pull
                    robot.y += (dy / mag) * pull
                    robot.apply_slow(0.7, 0.2)
                    if random.random() < 0.05:
                        particles.emit_trail(int(robot.x), int(robot.y),
                                              self.color, math.pi, speed=30, size=2, lifetime=0.2)
            return new_turrets_to_place

        if self.special == "reflect_damage":
            # Mirror tower: handled externally when adjacent turrets are damaged
            pass

        if self.special == "black_hole":
            # Black hole: suck and crush nearby robots
            for robot in robots:
                if not robot.alive:
                    continue
                d = dist(self.x, self.y, robot.x, robot.y)
                if d < range_px:
                    # Pull strongly
                    pull = CELL_W * 1.5 * dt
                    dx = self.x - robot.x
                    dy = self.y - robot.y
                    mag = max(1, math.sqrt(dx * dx + dy * dy))
                    robot.x += (dx / mag) * pull
                    robot.y += (dy / mag) * pull
                    # If very close, deal damage
                    if d < CELL_W:
                        robot.take_damage(self.damage * dt, self)
                        particles.emit_spark(int(robot.x), int(robot.y),
                                              self.color, count=2)
            return new_turrets_to_place

        # Time distorter
        if self.special == "slow_all_80pct_8s":
            self._time_dist_timer -= dt
            if self._time_dist_timer <= 0:
                self._time_dist_timer = self._time_dist_cd
                for robot in robots:
                    if robot.alive:
                        robot.apply_slow(0.2, 8.0)
                particles.emit_burst(int(self.x), int(self.y),
                                      COLORS["neon_cyan"], count=20, speed=120, size=3, lifetime=0.6)
            return new_turrets_to_place

        # Replicator
        if self.special == "duplicate_neighbor_10s" and not self._replicator_done and all_turrets:
            self._replicator_timer += dt
            if self._replicator_timer >= 10.0:
                self._replicator_done = True
                # Find nearest neighbor
                best = None
                best_d = CELL_W * 2
                for t in all_turrets:
                    if t is self or not t.alive:
                        continue
                    d = dist(self.x, self.y, t.x, t.y)
                    if d < best_d:
                        best_d = d
                        best = t
                if best:
                    new_turrets_to_place.append((best.id, self.col - 1, self.row))
                    particles.emit_burst(int(self.x), int(self.y),
                                          COLORS["neon_green"], count=15, speed=80, size=3, lifetime=0.5)
            return new_turrets_to_place

        # Overcharge cannon
        if self.special == "screen_clear_20s":
            self._overcharge_timer += dt
            if self._overcharge_timer >= self._overcharge_max:
                self._overcharge_timer = 0.0
                proj = OmegaBeamProjectile(self.x, self.y, self.damage, self.color, owner=self)
                projectiles.append(proj)
                particles.emit_explosion(int(self.x), int(self.y), self.color, 60)
            return new_turrets_to_place

        # Omega cannon
        if self.special == "sweep_all_lanes_60s":
            self._omega_timer += dt
            if self._omega_timer >= self._omega_max:
                self._omega_timer = 0.0
                proj = OmegaBeamProjectile(self.x, self.y, self.damage, self.color, owner=self)
                projectiles.append(proj)
                particles.emit_explosion(int(self.x), int(self.y), self.color, 80)
            return new_turrets_to_place

        # ── Active firing ────────────────────────────────────────────────────
        if not self.fire_timer.ready():
            return new_turrets_to_place
        if self.fire_rate <= 0:
            return new_turrets_to_place

        targets = self._get_targets(robots, range_px)
        if not targets:
            return new_turrets_to_place

        self.fire_timer.use()
        target = targets[0]

        # Point toward target
        dx = target.x - self.x
        dy = target.y - self.y
        self.rotation = math.degrees(math.atan2(dy, dx))

        # ── Photon Fortress: fire at all targets/lanes ───────────────────────
        if self.special == "all_lanes":
            for robot in targets:
                self._fire_at(robot, projectiles, particles)
            return new_turrets_to_place

        # ── Three-lane spread ────────────────────────────────────────────────
        if self.special == "three_lane_spread":
            for lane_offset in [-1, 0, 1]:
                target_row = clamp(self.row + lane_offset, 0, GRID_ROWS - 1)
                # Find first robot in that lane
                lane_target = None
                for robot in robots:
                    if robot.alive and robot.row == target_row:
                        d = dist(self.x, self.y, robot.x, robot.y)
                        if d <= range_px:
                            if lane_target is None or robot.x < lane_target.x:
                                lane_target = robot
                if lane_target:
                    self._fire_at(lane_target, projectiles, particles)
            return new_turrets_to_place

        # ── Single use explode (shock mine) ─────────────────────────────────
        if self.special == "single_use_explode":
            for robot in robots:
                if robot.alive and robot.row == self.row:
                    d = dist(self.x, self.y, robot.x, robot.y)
                    if d < CELL_W:
                        proj = ExplosionProjectile(self.x, self.y, self.damage, self.color,
                                                    radius=CELL_W * 1.5, owner=self)
                        projectiles.append(proj)
                        self.alive = False   # single use
                        return new_turrets_to_place
            return new_turrets_to_place

        # ── Chain lightning ──────────────────────────────────────────────────
        if self.special == "chain_4":
            proj = ChainLightningProjectile(self.x, self.y, target, self.damage,
                                             self.color, chain_max=4, owner=self)
            projectiles.append(proj)
            return new_turrets_to_place

        # ── Sonic wave ───────────────────────────────────────────────────────
        if self.special == "knockback_2":
            proj = SonicWaveProjectile(self.x, self.y, self.damage, self.color,
                                        max_radius=CELL_W * 2.5, owner=self)
            projectiles.append(proj)
            return new_turrets_to_place

        # ── Default single shot ──────────────────────────────────────────────
        self._fire_at(target, projectiles, particles)
        return new_turrets_to_place

    def _fire_at(self, target, projectiles, particles):
        """Create and fire a projectile at a target."""
        proj = Projectile(
            self.x, self.y,
            target.x, target.y,
            self.damage * self.damage_boost,
            self.color,
            proj_type=self.proj_type or "laser",
            speed=self._proj_speed(),
            owner=self,
            pierce=(self.special == "pierce")
        )

        # Apply effects based on special
        if self.special == "slow_60":
            proj.effects["slow"] = 0.4
            proj.effects["slow_duration"] = 3.0
        if self.special == "stun_2s":
            proj.effects["stun"] = True
            proj.effects["stun_duration"] = 2.0
        if self.special == "burn_dot":
            proj.effects["burn"] = True
            proj.effects["burn_dmg"] = 15
            proj.effects["burn_duration"] = 3.0
        if self.special == "armor_shred":
            proj.effects["armor_shred"] = True
        if self.special == "instakill_30pct":
            proj.effects["instakill"] = True
        if self.special == "homing_lowest_hp":
            proj.homing = True
            proj.homing_target = target
            proj.speed = 350

        projectiles.append(proj)
        particles.emit_trail(int(self.x), int(self.y), self.color,
                              math.atan2(target.y - self.y, target.x - self.x),
                              speed=30, size=1, lifetime=0.1)

    def _proj_speed(self):
        speeds = {
            "laser": 700, "plasma_pierce": 500, "arc_ball": 300, "arc_ball": 300,
            "cryo_bolt": 400, "scatter_shot": 450, "flame_stream": 350,
            "emp_pulse": 450, "rail_beam": 900, "chain_lightning": 999,
            "quantum_shot": 600, "acid_glob": 350, "sonic_wave": 0,
            "homing_missile": 350, "photon_beam": 800, "omega_beam": 0,
        }
        return speeds.get(self.proj_type, 600)

    # ─── Draw ─────────────────────────────────────────────────────────────────
    def draw(self, surface):
        if not self.alive:
            return
        cx, cy = int(self.x), int(self.y)

        # Glow
        draw_glow(surface, cx, cy, 26, self.color, intensity=0.25)

        # Draw sprite (rotated for cannons)
        if self.proj_type in ("laser", "plasma_pierce", "arc_ball", "rail_beam",
                               "cryo_bolt", "scatter_shot", "flame_stream",
                               "emp_pulse", "quantum_shot", "acid_glob"):
            rotated = pygame.transform.rotate(self.sprite, -self.rotation)
        elif self.special == "all_lanes" or self.special == "screen_clear_20s":
            rotated = pygame.transform.rotate(self.sprite, self.orbit_angle * 0.5)
        else:
            rotated = self.sprite

        r = rotated.get_rect(center=(cx, cy))
        surface.blit(rotated, r)

        # Shield node: draw barrier
        if self.special == "barrier":
            draw_shield_barrier(surface, cx - CELL_W // 4, cy - CELL_H // 2,
                                  CELL_W // 2, CELL_H)

        # Nano swarm: orbiting dots
        if self.special == "orbit_damage":
            for i in range(4):
                angle = math.radians(self.orbit_angle + i * 90)
                nx = cx + int(CELL_W * 0.55 * math.cos(angle))
                ny = cy + int(CELL_W * 0.55 * math.sin(angle))
                pygame.draw.circle(surface, self.color, (nx, ny), 4)
                draw_glow(surface, nx, ny, 6, self.color, intensity=0.4)

        # Overcharge charge bar
        if self.special == "screen_clear_20s":
            frac = self._overcharge_timer / self._overcharge_max
            bar_w = 36
            pygame.draw.rect(surface, COLORS["hp_bar_bg"],
                              (cx - bar_w // 2, cy + 22, bar_w, 4))
            pygame.draw.rect(surface, COLORS["neon_yellow"],
                              (cx - bar_w // 2, cy + 22, int(bar_w * frac), 4))

        # HP bar
        if self.hp < self.max_hp:
            bar_w = 36
            draw_hp_bar(surface, cx - bar_w // 2, cy + 28, bar_w, 5, self.hp, self.max_hp)

        # Stun indicator
        if self.stun_timer > 0:
            pygame.draw.circle(surface, COLORS["neon_yellow"], (cx, cy - 28), 5)


# ─── Generator ────────────────────────────────────────────────────────────────

class Generator(Turret):
    """Energy-producing unit. Drops energy cores periodically."""

    def __init__(self, gen_id: str, col: int, row: int):
        # Generators share the Turret base but have no attack
        data = GENERATORS[gen_id]
        # Build a fake turret-compatible dict
        fake_turret = {
            "id": gen_id, "name": data["name"], "cost": data["cost"],
            "recharge": data.get("recharge", 5.0),
            "hp": data["hp"], "damage": 0, "fire_rate": 0, "range": 0,
            "projectile_type": None, "special": data.get("special"),
            "color": data["color"], "tier": 1, "targeting": "none",
        }
        TURRETS[gen_id] = fake_turret   # temporarily register

        super().__init__(gen_id, col, row)
        self.is_generator = True
        self.drop_rate = data["drop_rate"]
        self.drop_amount = data.get("drop_amount", 1)
        self.gen_special = data.get("special")
        self.drop_timer = Cooldown(self.drop_rate, ready=False)
        self._pending_drops = []       # (x, y) positions for dropped cores

    def update(self, dt, robots, projectiles, particles, grid=None, all_turrets=None):
        if not self.alive:
            return []

        self.drop_timer.update(dt)

        # Adjacent damage boost (fusion reactor)
        if self.gen_special == "boost_adjacent_10pct" and all_turrets:
            for t in all_turrets:
                if (abs(t.col - self.col) + abs(t.row - self.row)) == 1:
                    t.damage_boost = 1.1

        # Overclock: double fire rate in same lane
        if self.gen_special == "double_firerate_lane_5s" and all_turrets:
            for t in all_turrets:
                if t.row == self.row:
                    t.fire_rate_boost = 2.0

        return []

    def should_drop(self):
        if self.drop_timer.ready():
            self.drop_timer.use()
            drops = []
            amount = self.drop_amount
            # 10% double drop for solar collector
            if self.gen_special == "double_drop_10pct" and random.random() < 0.1:
                amount *= 2
            for _ in range(amount):
                drops.append((self.x + random.uniform(-15, 15),
                               self.y + random.uniform(-10, 10)))
            return drops
        return []

    def draw(self, surface):
        super().draw(surface)
        # Show drop timer as a fill ring
        cx, cy = int(self.x), int(self.y)
        frac = self.drop_timer.fraction()
        if frac < 1.0:
            rect = pygame.Rect(cx - 20, cy - 20, 40, 40)
            pygame.draw.arc(surface, self.color, rect,
                             math.pi / 2 - math.pi * 2 * frac, math.pi / 2, 3)
