"""
game/projectile.py — All projectile types with movement, impact, and visual trail logic.
"""

import math
import pygame
from settings import COLORS, GRID_OFFSET_X, GRID_OFFSET_Y, CELL_W, CELL_H, GRID_ROWS
from utils.helpers import dist, normalize, clamp
from utils.draw_sprites import make_projectile_sprite
from game.particle import ParticleSystem


class Projectile:
    """Base class for all projectiles."""

    def __init__(self, x, y, target_x, target_y, damage, color,
                 proj_type="laser", speed=600, owner=None, pierce=False):
        self.x = float(x)
        self.y = float(y)
        self.target_x = float(target_x)
        self.target_y = float(target_y)
        self.damage = damage
        self.color = color
        self.proj_type = proj_type
        self.speed = speed
        self.owner = owner          # Turret that fired this
        self.pierce = pierce        # Does it continue after hitting?
        self.alive = True
        self.hit_robots = set()     # For pierce: don't double-hit
        self.trail_timer = 0.0
        self.radius = 6

        dx, dy = target_x - x, target_y - y
        self.vx, self.vy = normalize(dx, dy)
        self.vx *= speed
        self.vy *= speed
        self.angle = math.atan2(dy, dx)

        # Special state
        self.chain_count = 0        # For chain lightning
        self.chain_max = 4
        self.homing = False         # For homing missiles
        self.homing_target = None
        self.effects = {}           # {"slow": 0.6, "duration": 3.0} etc.

    def update(self, dt, robots, particles: ParticleSystem):
        if not self.alive:
            return []

        old_x, old_y = self.x, self.y

        # Homing update
        if self.homing and self.homing_target and self.homing_target.alive:
            tx, ty = self.homing_target.x, self.homing_target.y
            dx, dy = tx - self.x, ty - self.y
            tdx, tdy = normalize(dx, dy)
            turn_speed = 3.0
            self.vx = self.vx + (tdx * self.speed - self.vx) * turn_speed * dt
            self.vy = self.vy + (tdy * self.speed - self.vy) * turn_speed * dt
            # Normalize
            mag = math.sqrt(self.vx ** 2 + self.vy ** 2)
            if mag > 0:
                self.vx = self.vx / mag * self.speed
                self.vy = self.vy / mag * self.speed
            self.angle = math.atan2(self.vy, self.vx)
        else:
            if self.homing:
                self.homing = False

        self.x += self.vx * dt
        self.y += self.vy * dt

        # Trail particles
        self.trail_timer += dt
        if self.trail_timer >= 0.03:
            self.trail_timer = 0.0
            particles.emit_trail(self.x, self.y, self.color,
                                  math.atan2(-self.vy, -self.vx),
                                  speed=20, size=2, lifetime=0.15)

        # Out of bounds check
        if (self.x < GRID_OFFSET_X - 50 or
                self.x > GRID_OFFSET_X + CELL_W * 10 or
                self.y < 0 or self.y > GRID_OFFSET_Y + CELL_H * GRID_ROWS + 50):
            self.alive = False
            return []

        # Collision detection
        return self._check_collisions(robots, particles)

    def _check_collisions(self, robots, particles):
        """Check and handle robot collisions. Returns list of hit robots."""
        hits = []
        for robot in robots:
            if not robot.alive:
                continue
            if robot in self.hit_robots:
                continue
            dx = self.x - robot.x
            dy = self.y - robot.y
            if abs(dx) < self.radius + robot.radius and abs(dy) < self.radius + robot.radius:
                hits.append(robot)
                self.hit_robots.add(robot)
                self._apply_hit(robot, particles)
                if not self.pierce:
                    self.alive = False
                    break
        return hits

    def _apply_hit(self, robot, particles):
        """Apply damage and effects to a robot."""
        actual_damage = self.damage
        # Apply effects
        if "slow" in self.effects:
            robot.apply_slow(self.effects["slow"], self.effects.get("slow_duration", 3.0))
        if "stun" in self.effects:
            robot.apply_stun(self.effects.get("stun_duration", 2.0))
        if "burn" in self.effects:
            robot.apply_burn(self.effects.get("burn_dmg", 15), self.effects.get("burn_duration", 3.0))
        if "armor_shred" in self.effects:
            robot.apply_armor_shred()
        if "instakill" in self.effects:
            import random
            if random.random() < 0.30 and robot.hp < 500:
                actual_damage = robot.hp + 9999

        robot.take_damage(actual_damage, self.owner)
        particles.emit_laser_hit(robot.x, robot.y, self.color)

    def draw(self, surface):
        if not self.alive:
            return
        # Draw rotated projectile
        sprite = make_projectile_sprite(self.proj_type, self.color, self.radius)
        angle_deg = -math.degrees(self.angle)
        rotated = pygame.transform.rotate(sprite, angle_deg)
        r = rotated.get_rect(center=(int(self.x), int(self.y)))
        surface.blit(rotated, r)


class ExplosionProjectile(Projectile):
    """A projectile that instantly explodes in a radius (shock mine)."""

    def __init__(self, x, y, damage, color, radius=60, owner=None):
        super().__init__(x, y, x, y, damage, color, "explosion", speed=0, owner=owner)
        self.explosion_radius = radius
        self.exploded = False
        self.visual_timer = 0.4   # show for 0.4s

    def update(self, dt, robots, particles):
        if not self.exploded:
            self.exploded = True
            hits = []
            for robot in robots:
                if not robot.alive:
                    continue
                d = dist(self.x, self.y, robot.x, robot.y)
                if d <= self.explosion_radius:
                    robot.take_damage(self.damage, self.owner)
                    hits.append(robot)
            particles.emit_explosion(int(self.x), int(self.y), self.color, self.explosion_radius)
            return hits

        self.visual_timer -= dt
        if self.visual_timer <= 0:
            self.alive = False
        return []

    def draw(self, surface):
        if not self.exploded:
            return
        frac = clamp(self.visual_timer / 0.4, 0, 1)
        from utils.draw_sprites import draw_explosion
        draw_explosion(surface, int(self.x), int(self.y),
                        int(self.explosion_radius * (1 - frac) + 10),
                        self.color, frac)


class SonicWaveProjectile(Projectile):
    """Expanding ring that knocks back robots."""

    def __init__(self, x, y, damage, color, max_radius=80, owner=None):
        super().__init__(x, y, x, y, damage, color, "sonic_wave", speed=0, owner=owner)
        self.max_radius = max_radius
        self.current_radius = 0
        self.expand_speed = max_radius * 2.5
        self.knockback_cells = 2

    def update(self, dt, robots, particles):
        if not self.alive:
            return []
        prev_r = self.current_radius
        self.current_radius = min(self.current_radius + self.expand_speed * dt, self.max_radius)

        hits = []
        for robot in robots:
            if not robot.alive or robot in self.hit_robots:
                continue
            d = dist(self.x, self.y, robot.x, robot.y)
            if prev_r <= d <= self.current_radius + 5:
                robot.take_damage(self.damage, self.owner)
                # Knockback: push robot right by knockback_cells
                robot.x += self.knockback_cells * CELL_W
                self.hit_robots.add(robot)
                hits.append(robot)
                particles.emit_spark(int(robot.x), int(robot.y), self.color)

        if self.current_radius >= self.max_radius:
            self.alive = False
        return hits

    def draw(self, surface):
        if not self.alive or self.current_radius <= 0:
            return
        frac = 1 - self.current_radius / self.max_radius
        alpha = int(180 * frac)
        r = int(self.current_radius)
        ring_surf = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
        pygame.draw.circle(ring_surf, (*self.color, alpha), (r + 2, r + 2), r, 3)
        surface.blit(ring_surf, (int(self.x) - r - 2, int(self.y) - r - 2))


class ChainLightningProjectile(Projectile):
    """Instantly chains to N nearest robots."""

    def __init__(self, x, y, first_target, damage, color, chain_max=4, owner=None):
        super().__init__(x, y, first_target.x, first_target.y,
                          damage, color, "chain_lightning", speed=9999, owner=owner)
        self.chain_targets = [first_target]
        self.chain_max = chain_max
        self.chain_range = CELL_W * 3
        self.resolved = False
        self.visual_lines = []     # list of ((x1,y1),(x2,y2)) for drawing
        self.visual_timer = 0.25

    def _find_chain_targets(self, all_robots):
        """BFS-style chain: from each target, find nearest un-hit robot."""
        import random
        while len(self.chain_targets) < self.chain_max:
            last = self.chain_targets[-1]
            best = None
            best_d = self.chain_range
            for r in all_robots:
                if not r.alive or r in self.chain_targets:
                    continue
                d = dist(last.x, last.y, r.x, r.y)
                if d < best_d:
                    best_d = d
                    best = r
            if best is None:
                break
            self.chain_targets.append(best)

    def update(self, dt, robots, particles):
        if self.resolved:
            self.visual_timer -= dt
            if self.visual_timer <= 0:
                self.alive = False
            return []

        self.resolved = True
        self._find_chain_targets(robots)

        # Build visual lines
        prev_x, prev_y = self.x, self.y
        for target in self.chain_targets:
            import random
            # Jagged lightning path
            mx = (prev_x + target.x) / 2 + random.uniform(-15, 15)
            my = (prev_y + target.y) / 2 + random.uniform(-15, 15)
            self.visual_lines.append(((prev_x, prev_y), (mx, my), (target.x, target.y)))
            prev_x, prev_y = target.x, target.y
            target.take_damage(self.damage, self.owner)
            particles.emit_spark(int(target.x), int(target.y), self.color, count=6)

        particles.emit_chain_lightning(int(self.x), int(self.y),
                                        int(self.chain_targets[-1].x) if self.chain_targets else int(self.x),
                                        int(self.chain_targets[-1].y) if self.chain_targets else int(self.y))
        return list(self.chain_targets)

    def draw(self, surface):
        if not self.resolved:
            return
        alpha = int(255 * clamp(self.visual_timer / 0.25, 0, 1))
        color = (*self.color, alpha)
        for seg in self.visual_lines:
            ls = pygame.Surface((max(2, abs(int(seg[2][0] - seg[0][0])) + 20),
                                   max(2, abs(int(seg[2][1] - seg[0][1])) + 20)), pygame.SRCALPHA)
            # Draw zigzag directly on surface
            pygame.draw.line(surface, color[:3], (int(seg[0][0]), int(seg[0][1])),
                              (int(seg[1][0]), int(seg[1][1])), 2)
            pygame.draw.line(surface, color[:3], (int(seg[1][0]), int(seg[1][1])),
                              (int(seg[2][0]), int(seg[2][1])), 2)
            # Glow
            pygame.draw.line(surface, (*color[:3], alpha // 3), (int(seg[0][0]), int(seg[0][1])),
                              (int(seg[2][0]), int(seg[2][1])), 5)


class OmegaBeamProjectile(Projectile):
    """Screen-sweeping beam that hits all robots in all lanes."""

    def __init__(self, x, y, damage, color, owner=None):
        super().__init__(x, y, x + 1, y, damage, color, "omega_beam", speed=0, owner=owner)
        self.beam_width = CELL_W * GRID_ROWS * 1.5
        self.beam_length = CELL_W * 9 + 100
        self.resolved = False
        self.visual_timer = 0.5

    def update(self, dt, robots, particles):
        if self.resolved:
            self.visual_timer -= dt
            if self.visual_timer <= 0:
                self.alive = False
            return []

        self.resolved = True
        hits = []
        for robot in robots:
            if robot.alive:
                robot.take_damage(self.damage, self.owner)
                hits.append(robot)
                particles.emit_explosion(int(robot.x), int(robot.y), self.color, 30)
        return hits

    def draw(self, surface):
        if not self.resolved:
            return
        frac = clamp(self.visual_timer / 0.5, 0, 1)
        beam_surf = pygame.Surface((int(self.beam_length), int(self.beam_width)), pygame.SRCALPHA)
        alpha = int(200 * frac)
        beam_surf.fill((*self.color, alpha // 4))
        pygame.draw.rect(beam_surf, (*self.color, alpha),
                          (0, self.beam_width // 2 - 5, int(self.beam_length), 10))
        from settings import GRID_OFFSET_Y, GRID_ROWS, CELL_H
        cy = GRID_OFFSET_Y + GRID_ROWS * CELL_H // 2
        surface.blit(beam_surf, (int(self.x), int(cy - self.beam_width // 2)))
