"""
game/level_loader.py — Parses level definitions and sequences robot waves.
"""

import pygame
from data.levels_data import LEVELS
from data.robots_data import ROBOTS
from settings import BETWEEN_WAVE_COUNTDOWN, COLORS, GRID_COLS
from utils.helpers import Cooldown


class WaveRobot:
    """A robot spawn instruction within a wave."""
    def __init__(self, robot_id: str, lane: int, count: int, interval: float):
        self.robot_id = robot_id
        self.lane = lane
        self.count = count
        self.interval = interval
        self.spawned = 0
        self.timer = 0.0

    def ready_to_spawn(self, dt) -> bool:
        if self.spawned >= self.count:
            return False
        self.timer += dt
        if self.timer >= self.interval or self.spawned == 0:
            self.timer = 0.0
            self.spawned += 1
            return True
        return False

    def done(self) -> bool:
        return self.spawned >= self.count


class Wave:
    """A single wave of robots."""
    def __init__(self, wave_data: dict):
        self.robot_spawners = [
            WaveRobot(r["id"], r["lane"], r["count"], r["interval"])
            for r in wave_data["robots"]
        ]
        self.started = False
        self.complete = False

    def update(self, dt) -> list:
        """Returns list of (robot_id, lane) to spawn this frame."""
        spawns = []
        for spawner in self.robot_spawners:
            if spawner.ready_to_spawn(dt):
                spawns.append((spawner.robot_id, spawner.lane))
        if all(s.done() for s in self.robot_spawners):
            self.complete = True
        return spawns


class LevelLoader:
    """Manages the current level state: waves, delays, boss triggers."""

    def __init__(self):
        self.level_data = None
        self.waves: list[Wave] = []
        self.current_wave_index = -1   # -1 = pregame, len = all done
        self.between_wave_timer = 0.0
        self.wave_delay_timer = 0.0
        self.state = "waiting"   # "waiting", "in_wave", "between", "boss", "complete"
        self.boss_spawned = False
        self.boss_wave_data = None
        self.active = False
        self.world = 1

    def load(self, level_id: int):
        """Load a level by ID."""
        self.level_data = LEVELS.get(level_id)
        if not self.level_data:
            raise ValueError(f"Level {level_id} not found")

        self.world = self.level_data["world"]
        self.waves = [Wave(w) for w in self.level_data["waves"]]
        self.boss_wave_data = self.level_data.get("boss_wave")
        self.current_wave_index = -1
        self.between_wave_timer = BETWEEN_WAVE_COUNTDOWN
        self.wave_delay_timer = 0.0
        self.state = "waiting"
        self.boss_spawned = False
        self.active = True

    def start_next_wave(self):
        """Manually start the next wave (Space bar)."""
        if self.state in ("waiting", "between"):
            self._advance_wave()

    def _advance_wave(self):
        self.current_wave_index += 1
        if self.current_wave_index < len(self.waves):
            wave_data = self.level_data["waves"][self.current_wave_index]
            self.wave_delay_timer = wave_data.get("delay", 0)
            self.state = "in_wave"
        elif not self.boss_spawned and self.boss_wave_data:
            self.state = "boss"
        else:
            self.state = "complete"

    def update(self, dt, active_robots: list) -> list:
        """Update wave sequencing. Returns list of (robot_id, lane) to spawn."""
        if not self.active:
            return []

        spawns = []

        if self.state == "waiting":
            self.between_wave_timer -= dt
            if self.between_wave_timer <= 0:
                self._advance_wave()

        elif self.state == "in_wave":
            # Initial wave delay
            if self.wave_delay_timer > 0:
                self.wave_delay_timer -= dt
                return []

            wave = self.waves[self.current_wave_index]
            new_spawns = wave.update(dt)
            spawns.extend(new_spawns)

            # Check if wave is done AND no robots remain
            if wave.complete and not active_robots:
                if self.current_wave_index + 1 < len(self.waves) or (
                        not self.boss_spawned and self.boss_wave_data):
                    self.state = "between"
                    self.between_wave_timer = BETWEEN_WAVE_COUNTDOWN
                else:
                    self.state = "complete"

        elif self.state == "between":
            self.between_wave_timer -= dt
            if self.between_wave_timer <= 0:
                self._advance_wave()

        elif self.state == "boss":
            if not self.boss_spawned and self.boss_wave_data:
                self.boss_spawned = True
                spawns.append((self.boss_wave_data["robot_id"],
                                self.boss_wave_data["lane"]))

            # Complete when boss is dead
            if self.boss_spawned and not active_robots:
                self.state = "complete"

        return spawns

    @property
    def is_complete(self) -> bool:
        return self.state == "complete"

    @property
    def total_waves(self) -> int:
        n = len(self.waves)
        if self.boss_wave_data:
            n += 1
        return n

    @property
    def display_wave_num(self) -> int:
        return max(1, self.current_wave_index + 1)

    @property
    def next_wave_countdown(self) -> float:
        """Seconds until next wave. 0 means press Space."""
        if self.state == "between":
            return max(0, self.between_wave_timer)
        if self.state == "waiting":
            return max(0, self.between_wave_timer)
        return -1   # -1 = wave in progress

    def get_available_turrets(self) -> list:
        return self.level_data["available_turrets"] if self.level_data else []

    def get_grid_modifiers(self) -> list:
        return self.level_data.get("grid_modifiers", []) if self.level_data else []

    def get_energy_start(self) -> int:
        return self.level_data.get("energy_start", 150) if self.level_data else 150

    def has_energy_drip(self) -> bool:
        return self.level_data.get("energy_drip", True) if self.level_data else True

    def get_background_variant(self) -> str:
        return self.level_data.get("background_variant", "day_orange") if self.level_data else "day_orange"

    def get_unlock_reward(self) -> str | None:
        return self.level_data.get("unlock_reward") if self.level_data else None

    def get_level_name(self) -> str:
        if self.level_data:
            return f"L{self.level_data['id']}: {self.level_data['name']}"
        return "Unknown"

    def apply_world5_boost(self, robot):
        """World 5 gives all robots +30% HP and speed."""
        if self.world == 5:
            robot.max_hp = int(robot.max_hp * 1.3)
            robot.hp = float(robot.max_hp)
            robot.base_speed *= 1.3
            robot.speed = robot.base_speed
