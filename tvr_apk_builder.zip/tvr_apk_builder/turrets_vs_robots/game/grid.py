"""
game/grid.py — The 9×7 game grid: cell state, modifiers, hit-testing, rendering.
"""

import pygame
from settings import (GRID_COLS, GRID_ROWS, CELL_W, CELL_H,
                       GRID_OFFSET_X, GRID_OFFSET_Y, COLORS)
from utils.draw_sprites import draw_grid_cell
from utils.helpers import pixel_to_grid, grid_to_pixel


class GridCell:
    """Represents one cell on the game grid."""
    def __init__(self, col, row):
        self.col = col
        self.row = row
        self.occupant = None        # Turret or Generator instance, or None
        self.modifier = None        # "flooded", "emf_zone", "darkness", etc.
        self.inactive_timer = 0.0   # for "deactivating" modifier
        self.is_inactive = False    # cell temporarily deactivated
        self.rect = pygame.Rect(
            GRID_OFFSET_X + col * CELL_W,
            GRID_OFFSET_Y + row * CELL_H,
            CELL_W, CELL_H
        )

    def is_empty(self):
        return self.occupant is None and not self.is_inactive

    def center(self):
        return self.rect.centerx, self.rect.centery


class Grid:
    """Manages the full 9×7 grid of cells."""

    def __init__(self):
        self.cells: list[list[GridCell]] = [
            [GridCell(c, r) for r in range(GRID_ROWS)]
            for c in range(GRID_COLS)
        ]
        self.hovered_cell = None
        self.modifiers_list = []    # raw modifier dicts from level data
        self._deactivate_timer = 0.0

    # ─── Setup ────────────────────────────────────────────────────────────────
    def apply_modifiers(self, modifiers: list):
        """Apply level-defined grid modifiers."""
        self.modifiers_list = modifiers
        for mod in modifiers:
            mtype = mod.get("type")
            if mtype in ("flooded", "emf_zone"):
                for col, row in mod.get("cells", []):
                    if 0 <= col < GRID_COLS and 0 <= row < GRID_ROWS:
                        self.cells[col][row].modifier = mtype
            elif mtype == "darkness":
                # Handled in turret range calcs, just mark all cells
                for col in range(GRID_COLS):
                    for row in range(GRID_ROWS):
                        self.cells[col][row].modifier = "darkness"
            elif mtype == "fog":
                for col in range(GRID_COLS):
                    for row in range(GRID_ROWS):
                        self.cells[col][row].modifier = "fog"
            elif mtype == "deactivating":
                pass  # handled in update()

    def get_modifier_value(self, key):
        """Return a modifier dict value from modifiers list by type."""
        for mod in self.modifiers_list:
            if mod.get("type") == key:
                return mod
        return None

    def reset(self):
        """Clear all occupants and modifiers."""
        for col in range(GRID_COLS):
            for row in range(GRID_ROWS):
                cell = self.cells[col][row]
                cell.occupant = None
                cell.modifier = None
                cell.is_inactive = False
                cell.inactive_timer = 0.0
        self.modifiers_list = []
        self._deactivate_timer = 0.0

    # ─── Access ───────────────────────────────────────────────────────────────
    def cell_at(self, col, row) -> GridCell | None:
        if 0 <= col < GRID_COLS and 0 <= row < GRID_ROWS:
            return self.cells[col][row]
        return None

    def cell_at_pixel(self, px, py) -> GridCell | None:
        pos = pixel_to_grid(px, py)
        if pos:
            return self.cells[pos[0]][pos[1]]
        return None

    def place_unit(self, col, row, unit) -> bool:
        cell = self.cell_at(col, row)
        if cell and cell.is_empty():
            cell.occupant = unit
            unit.col = col
            unit.row = row
            x, y = grid_to_pixel(col, row)
            unit.x = x
            unit.y = y
            return True
        return False

    def remove_unit(self, col, row):
        cell = self.cell_at(col, row)
        if cell:
            cell.occupant = None

    def get_occupants_in_row(self, row):
        """Return all occupants in a given row (lane), sorted by column."""
        result = []
        for col in range(GRID_COLS):
            cell = self.cells[col][row]
            if cell.occupant is not None:
                result.append(cell.occupant)
        return result

    def get_all_occupants(self):
        result = []
        for col in range(GRID_COLS):
            for row in range(GRID_ROWS):
                occ = self.cells[col][row].occupant
                if occ is not None:
                    result.append(occ)
        return result

    def range_penalty(self) -> int:
        """Return range reduction from fog modifier."""
        for mod in self.modifiers_list:
            if mod.get("type") == "fog":
                return mod.get("range_penalty", 0)
            if mod.get("type") == "darkness":
                return 7   # very short range
        return 0

    def emf_affected(self, col, row) -> bool:
        return self.cells[col][row].modifier == "emf_zone"

    def flooded_cell(self, col, row) -> bool:
        return self.cells[col][row].modifier == "flooded"

    # ─── Update ───────────────────────────────────────────────────────────────
    def update(self, dt):
        """Handle deactivating modifier logic."""
        import random
        deact_mod = self.get_modifier_value("deactivating")
        if deact_mod:
            chance = deact_mod.get("chance", 0.1)
            interval = deact_mod.get("interval", 5.0)
            self._deactivate_timer += dt
            if self._deactivate_timer >= interval:
                self._deactivate_timer = 0.0
                # Re-activate previously inactive empty cells
                for col in range(GRID_COLS):
                    for row in range(GRID_ROWS):
                        cell = self.cells[col][row]
                        if cell.is_inactive and cell.occupant is None:
                            cell.is_inactive = False
                # Randomly deactivate some empty cells
                for col in range(GRID_COLS):
                    for row in range(GRID_ROWS):
                        cell = self.cells[col][row]
                        if cell.occupant is None and random.random() < chance:
                            cell.is_inactive = True

    def set_hover(self, px, py):
        """Update which cell is currently hovered by the mouse."""
        cell = self.cell_at_pixel(px, py)
        self.hovered_cell = cell

    # ─── Draw ─────────────────────────────────────────────────────────────────
    def draw(self, surface):
        for col in range(GRID_COLS):
            for row in range(GRID_ROWS):
                cell = self.cells[col][row]
                hovered = (self.hovered_cell is cell)
                draw_grid_cell(surface, cell.rect, cell.modifier, hovered, cell.occupant is not None)
                if cell.is_inactive:
                    overlay = pygame.Surface((CELL_W, CELL_H), pygame.SRCALPHA)
                    overlay.fill((0, 0, 0, 120))
                    surface.blit(overlay, cell.rect.topleft)

        # Draw lane entrance arrows (right edge indicators)
        for row in range(GRID_ROWS):
            ax = GRID_OFFSET_X + GRID_COLS * CELL_W + 8
            ay = GRID_OFFSET_Y + row * CELL_H + CELL_H // 2
            pygame.draw.polygon(surface, COLORS["neon_red"],
                                 [(ax, ay - 6), (ax + 12, ay), (ax, ay + 6)])
