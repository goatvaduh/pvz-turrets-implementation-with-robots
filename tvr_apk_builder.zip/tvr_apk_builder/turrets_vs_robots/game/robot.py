"""
game/robot.py — Robot base class and all enemy behaviors.
Robots walk left across lanes and attack turrets that block their path.
"""

import math
import random
import pygame
from settings import (COLORS, GRID_OFFSET_X, GRID_OFFSET_Y, GRID_COLS, GRID_ROWS,
                       CELL_W, CELL_H)
from utils.helpers import clamp, draw_hp_bar, draw_glow
from utils.draw_sprites import draw_robot
from data.robots_data import ROBOTS


class Robot:
    """Base robot class. All robot types are instances of this class
    configured with data from ROBOTS dict."""

    SPRITE_CACHE = {}   # {robot_id: pygame.Surface}

    def __init__(self, robot_id: str, lane: int, start_col: int = None):
        data = ROBOTS[robot_id]
        self.id = robot_id
        self.name = data["name"]
        self.lane = lane
        self.row = lane

        # Stats (can be modified by world 5 +30% boost)
        self.max_hp = data["hp"]
        self.hp = float(self.max_hp)
        self.base_speed = data["speed"]   # cells per second
        self.speed = self.base_speed
        self.armor = data["armor"]
        self.base_damage = data["damage"]
        self.damage = self.base_damage
        self.attack_rate = data["attack_rate"]
        self.special = data.get("special")
        self.color = data["color"]
        self.size = data.get("size", "small")
        self.score_value = data.get("score_value", 10)

        # Position (in pixels)
        col = start_col if start_col is not None else GRID_COLS
        self.x = float(GRID_OFFSET_X + col * CELL_W + CELL_W // 2)
        self.y = float(GRID_OFFSET_Y + lane * CELL_H + CELL_H // 2)
        self.col = float(col)

        # State machine
        self.alive = True
        self.state = "walking"   # "walking", "attacking", "dead", "stunned"
        self.current_target = None    # turret/generator being attacked
        self.attack_timer = 0.0
        self.stun_timer = 0.0

        # Status effects
        self.slow_factor = 1.0
        self.slow_timer = 0.0
        self.burn_dmg = 0.0
        self.burn_timer = 0.0
        self.burn_rate = 0.0
        self.armor_shredded = False
        self.is_frozen = False

        # Special state tracking
        self.shield_hp = 0
        if self.special == "front_shield_50":
            self.shield_hp = 50
        self.has_jumped = False
        self.has_phased = False
        self.berserker_active = False
        self.spawn_drone_timer = 0.0
        self.plasma_shields = 3 if self.special == "plasma_shields_3" else 0
        self.teleport_timer = 0.0
        self.absorb_timer = 1.0   # for nano_cloud: absorbs 1 proj/sec
        self.stealth = (self.special == "stealth_until_attack")
        self.is_stealth = self.stealth
        self.warp_timer = 5.0 if self.special == "teleport_2cells_5s" else 0.0
        self.boss_phase = 0   # for multi-phase bosses
        self.radius = {"small": 14, "medium": 18, "large": 24, "boss": 34}.get(self.size, 14)

        # Walking animation
        self._walk_phase = random.uniform(0, 1.0)   # offset so robots don't sync
        self._walk_speed_mult = 1.0                  # updated each frame from effective speed

        # No longer caching a pre-drawn sprite — we draw procedurally each frame
        self.sprite = None

        # EMF jammer range
        self.jammer_active = (self.special == "double_turret_cooldowns")
        self.jammer_range = CELL_W * 2.5

        # Heal aura
        self.healer = (self.special == "heal_nearest_30ps")
        self.heal_timer = 0.0

        # Overclock aura
        self.overclocker = (self.special == "boost_nearby_speed_50pct")

    # ─── Status effects ───────────────────────────────────────────────────────
    def apply_slow(self, factor, duration):
        if "immune_slow" in (self.special or ""):
            return
        self.slow_factor = min(self.slow_factor, factor)
        self.slow_timer = max(self.slow_timer, duration)

    def apply_stun(self, duration):
        self.stun_timer = max(self.stun_timer, duration)
        self.state = "stunned"

    def apply_burn(self, dmg_per_sec, duration):
        self.burn_rate = max(self.burn_rate, dmg_per_sec)
        self.burn_timer = max(self.burn_timer, duration)

    def apply_armor_shred(self):
        self.armor_shredded = True

    def take_damage(self, amount, source=None):
        """Apply damage with armor reduction."""
        if not self.alive:
            return

        # Plasma shields
        if self.plasma_shields > 0:
            self.plasma_shields -= 1
            return

        # Shield absorption (shielder front shield)
        if self.shield_hp > 0:
            absorbed = min(self.shield_hp, amount)
            self.shield_hp -= absorbed
            amount -= absorbed
            if amount <= 0:
                return

        # Armor
        reduction = self.armor
        if self.armor_shredded:
            amount *= 1.3
            reduction = 0

        actual = max(1.0, amount - reduction)
        self.hp -= actual

        # Check stealth reveal
        if self.is_stealth:
            self.is_stealth = False

        # Berserker trigger
        if (self.special == "berserker_below_50pct" and
                not self.berserker_active and self.hp <= self.max_hp * 0.5):
            self.berserker_active = True
            self.speed = self.base_speed * 2.0
            self.damage = self.base_damage * 3

        if self.hp <= 0:
            self.hp = 0
            self.die()

    def die(self):
        self.alive = False
        self.state = "dead"

    # ─── Update ───────────────────────────────────────────────────────────────
    def update(self, dt, all_turrets, all_robots, grid, particles):
        """Main update — returns list of new robots to spawn (from split/spawn specials)."""
        if not self.alive:
            return []

        new_spawns = []

        # Advance walk animation
        if self.state == "walking":
            self._walk_phase += dt * self.speed * self.slow_factor * 2.8
            if self._walk_phase > 1.0:
                self._walk_phase -= 1.0

        # Stun
        if self.stun_timer > 0:
            self.stun_timer -= dt
            if self.stun_timer <= 0:
                self.stun_timer = 0
                if self.state == "stunned":
                    self.state = "walking"
            return new_spawns

        # Status effects
        if self.slow_timer > 0:
            self.slow_timer -= dt
            if self.slow_timer <= 0:
                self.slow_factor = 1.0
        if self.burn_timer > 0:
            self.burn_timer -= dt
            dmg = self.burn_rate * dt
            self.take_damage(dmg)
            if self.burn_timer <= 0:
                self.burn_rate = 0.0

        # Heal aura
        if self.healer:
            self.heal_timer += dt
            if self.heal_timer >= 1.0 / 30.0:
                self.heal_timer = 0.0
                nearest = self._nearest_robot(all_robots, exclude_self=True)
                if nearest and nearest.hp < nearest.max_hp:
                    nearest.hp = min(nearest.max_hp, nearest.hp + 30 * dt)

        # Warp special
        if self.special == "teleport_2cells_5s" and self.state == "walking":
            self.warp_timer -= dt
            if self.warp_timer <= 0:
                self.warp_timer = 5.0
                self.x -= CELL_W * 2
                self.col -= 2.0
                particles.emit_burst(int(self.x), int(self.y),
                                      COLORS["neon_cyan"], count=10, speed=50, size=3, lifetime=0.4)

        # Swarm core: spawn drones periodically
        if self.special == "spawn_drones_8s" and self.alive:
            self.spawn_drone_timer += dt
            if self.spawn_drone_timer >= 8.0:
                self.spawn_drone_timer = 0.0
                # Spawn 4 mini crawlers (returned as new_spawns)
                for _ in range(4):
                    mini = Robot("crawler", self.lane)
                    mini.x = self.x
                    mini.y = self.y
                    mini.hp = 40
                    mini.max_hp = 40
                    new_spawns.append(mini)

        # Hive mother boss: spawn crawlers
        if self.special == "spawn_crawlers_5s" and self.alive:
            self.spawn_drone_timer += dt
            if self.spawn_drone_timer >= 5.0:
                self.spawn_drone_timer = 0.0
                for lane_offset in range(-1, 2):
                    tgt_lane = clamp(self.lane + lane_offset, 0, GRID_ROWS - 1)
                    mini = Robot("crawler", tgt_lane)
                    mini.x = self.x
                    mini.y = GRID_OFFSET_Y + tgt_lane * CELL_H + CELL_H // 2
                    new_spawns.append(mini)

        # State machine
        effective_speed = self.speed * self.slow_factor
        # How close (px) a robot must get before it starts dealing damage
        MELEE_RANGE = CELL_W * 0.72

        if self.state == "walking":
            # Find first blocking turret in this lane ahead of robot
            target_turret = self._find_blocking_turret(all_turrets)

            if target_turret:
                gap = self.x - (target_turret.x + CELL_W * 0.5)

                # Jump special: leap over first turret once
                if self.special == "jump_over_first_turret" and not self.has_jumped:
                    if gap < CELL_W * 1.5:
                        self.has_jumped = True
                        self.x = target_turret.x - CELL_W * 0.6
                        self.col = (self.x - GRID_OFFSET_X) / CELL_W
                        particles.emit_burst(int(self.x), int(self.y),
                                              COLORS["neon_cyan"], count=8, speed=60, size=3, lifetime=0.3)
                    else:
                        # Still walking toward it
                        move = effective_speed * CELL_W * dt
                        self.x -= move
                        self.col = (self.x - GRID_OFFSET_X) / CELL_W

                elif self.special == "phase_through_one" and not self.has_phased:
                    # Phase-through: walk straight past without stopping
                    if gap < MELEE_RANGE:
                        self.has_phased = True
                    move = effective_speed * CELL_W * dt
                    self.x -= move
                    self.col = (self.x - GRID_OFFSET_X) / CELL_W

                elif gap <= MELEE_RANGE:
                    # Close enough — start attacking
                    self.state = "attacking"
                    self.current_target = target_turret
                    # Snap to just beside the turret
                    self.x = target_turret.x + CELL_W * 0.55
                    self.col = (self.x - GRID_OFFSET_X) / CELL_W
                else:
                    # Walk toward the turret
                    move = effective_speed * CELL_W * dt
                    self.x -= move
                    self.col = (self.x - GRID_OFFSET_X) / CELL_W
            else:
                # No turret ahead — walk left freely
                move = effective_speed * CELL_W * dt
                self.x -= move
                self.col = (self.x - GRID_OFFSET_X) / CELL_W

                # Particle trail for fast bots
                if self.speed >= 1.5:
                    if random.random() < 0.3:
                        particles.emit_trail(self.x, self.y, self.color,
                                              math.pi, speed=20, size=1, lifetime=0.15)

        elif self.state == "attacking":
            if not self.current_target or not self.current_target.alive:
                self.current_target = None
                self.state = "walking"
            else:
                # Corrosive: leave acid trail
                if self.special == "acid_trail":
                    if random.random() < 0.05:
                        particles.emit_burst(int(self.x), int(self.y),
                                              (100, 255, 50), count=3, speed=20, size=2, lifetime=0.5)

                self.attack_timer += dt
                if self.attack_timer >= 1.0 / self.attack_rate:
                    self.attack_timer = 0.0
                    # Melee attack — must be touching the turret
                    self.current_target.take_damage(self.damage)
                    particles.emit_spark(int(self.current_target.x),
                                          int(self.current_target.y),
                                          self.color, count=4)
                    # Discharge special for tesla_bot
                    if self.special == "discharge_on_hit":
                        for turret in all_turrets:
                            d = math.sqrt((turret.x - self.x) ** 2 + (turret.y - self.y) ** 2)
                            if d < CELL_W * 2.5:
                                turret.stun(1.0)
                        particles.emit_spark(int(self.x), int(self.y),
                                              COLORS["neon_yellow"], count=8)

        # Check if reached home (col < 0)
        if self.col < 0:
            self.alive = False
            return new_spawns, True   # signals a robot got through

        return new_spawns

    def _find_blocking_turret(self, all_turrets):
        """Find the nearest turret directly ahead (to the left) in this lane.
        Robots must physically walk up to it — no ranged targeting."""
        best = None
        best_col = -1
        for turret in all_turrets:
            if not turret.alive:
                continue
            if turret.row != self.row:
                continue
            # Turret must be to the robot's left (ahead in direction of travel)
            if turret.col >= self.col:
                continue
            # Phase-through: skip the first turret we already phased
            if self.special == "phase_through_one" and self.has_phased and best is None:
                continue
            if turret.col > best_col:
                best_col = turret.col
                best = turret
        return best

    def _nearest_robot(self, all_robots, exclude_self=False):
        best = None
        best_d = float("inf")
        for r in all_robots:
            if not r.alive:
                continue
            if exclude_self and r is self:
                continue
            d = math.sqrt((r.x - self.x) ** 2 + (r.y - self.y) ** 2)
            if d < best_d:
                best_d = d
                best = r
        return best

    # ─── On-death effects ─────────────────────────────────────────────────────
    def on_death(self, all_turrets, particles):
        """Handle death special effects. Returns new robots to spawn."""
        new_spawns = []

        if self.special == "death_explode_30":
            # Damage adjacent turrets
            for turret in all_turrets:
                d = math.sqrt((turret.x - self.x) ** 2 + (turret.y - self.y) ** 2)
                if d <= CELL_W * 1.5:
                    turret.take_damage(30)
            particles.emit_explosion(int(self.x), int(self.y), COLORS["neon_orange"], 50)

        elif self.special == "split_2_crawlers":
            for _ in range(2):
                mini = Robot("crawler", self.lane)
                mini.x = self.x + random.uniform(-10, 10)
                mini.y = self.y + random.uniform(-5, 5)
                new_spawns.append(mini)
            particles.emit_burst(int(self.x), int(self.y),
                                   self.color, count=12, speed=60, size=3, lifetime=0.4)

        return new_spawns

    # ─── Draw ─────────────────────────────────────────────────────────────────
    def draw(self, surface):
        if not self.alive:
            return

        cx, cy = int(self.x), int(self.y)

        draw_robot(
            surface,
            robot_data_id=self.id,
            robot_color=self.color,
            robot_size=self.size,
            cx=cx, cy=cy,
            walk_phase=self._walk_phase,
            is_stealth=self.is_stealth,
            is_attacking=(self.state == "attacking"),
            slow_active=(self.slow_timer > 0),
            burn_active=(self.burn_timer > 0),
            stun_active=(self.stun_timer > 0),
            berserker=self.berserker_active,
            plasma_shields=self.plasma_shields,
            hp_frac=self.hp / max(1, self.max_hp),
            shield_hp_frac=self.shield_hp / 50.0 if self.shield_hp > 0 else 0,
            jammer_active=self.jammer_active,
        )

        # HP bar (only if damaged)
        if self.hp < self.max_hp:
            bar_w = self.radius * 2 + 4
            draw_hp_bar(surface, cx - bar_w // 2, cy - self.radius - 18,
                         bar_w, 5, self.hp, self.max_hp)

        # Shield bar above HP bar
        if self.shield_hp > 0:
            bar_w = self.radius * 2 + 4
            pygame.draw.rect(surface, COLORS["neon_blue"],
                              (cx - bar_w // 2, cy - self.radius - 25, bar_w, 4),
                              border_radius=2)
