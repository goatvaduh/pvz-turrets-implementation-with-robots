"""
game/gameplay.py — The main gameplay state. Orchestrates grid, turrets, robots,
projectiles, particles, energy, and waves into a running game loop.
"""

import pygame
import random
import math
from settings import (COLORS, SCREEN_W, SCREEN_H, GRID_COLS, GRID_ROWS,
                       CELL_W, CELL_H, GRID_OFFSET_X, GRID_OFFSET_Y,
                       MAX_ROBOTS_THROUGH, SKY_DROP_INTERVAL,
                       STATE_WIN, STATE_LOSE, STATE_PAUSED)
from utils.helpers import Cooldown, clamp, grid_to_pixel, pixel_to_grid, render_text, draw_glow, draw_rounded_rect
from utils.draw_sprites import draw_background, draw_scanline_overlay
from game.grid import Grid
from game.turret import Turret, Generator
from game.robot import Robot
from game.projectile import Projectile
from game.particle import ParticleSystem
from game.energy_core import EnergyCore, SkyDropSystem
from game.level_loader import LevelLoader
from game.ui import HUD, draw_robot_breach_warning, draw_pause_overlay
from data.turrets_data import TURRETS, GENERATORS


class GameplayState:
    """Full in-game state. Call update() and draw() each frame."""

    def __init__(self, save_data: dict = None):
        self.grid = Grid()
        self.turrets: list[Turret] = []
        self.robots: list[Robot] = []
        self.projectiles: list[Projectile] = []
        self.energy_cores: list[EnergyCore] = []
        self.particles = ParticleSystem()
        self.hud = HUD()
        self.level_loader = LevelLoader()
        self.sky_drops = SkyDropSystem(SKY_DROP_INTERVAL)
        self.save_data = save_data or {}

        # Card cooldowns per turret id
        self._card_cooldowns: dict[str, Cooldown] = {}

        self.energy = 150
        self.score = 0
        self.robots_through = 0
        self.result = None     # STATE_WIN or STATE_LOSE
        self.paused = False
        self._bg_scroll = 0.0
        self._cached_bg = None
        self._bg_variant = "day_orange"
        self._emergency_drones = [True] * GRID_ROWS   # one per lane
        self._drone_animations: list[dict] = []

        # Sell tooltip
        self._sell_target: Turret | None = None
        self._sell_rect = None

        self.current_level = 1

    def load_level(self, level_id: int):
        """Reset state and load a new level."""
        self.grid.reset()
        self.turrets.clear()
        self.robots.clear()
        self.projectiles.clear()
        self.energy_cores.clear()
        self.particles.clear()
        self._card_cooldowns.clear()
        self._drone_animations.clear()
        self._emergency_drones = [True] * GRID_ROWS
        self.robots_through = 0
        self.score = 0
        self.result = None
        self.paused = False
        self._sell_target = None

        self.current_level = level_id
        self.level_loader.load(level_id)
        self.grid.apply_modifiers(self.level_loader.get_grid_modifiers())
        self.energy = self.level_loader.get_energy_start()
        self.sky_drops.enabled = self.level_loader.has_energy_drip()

        available = self.level_loader.get_available_turrets()
        for tid in available:
            recharge = (TURRETS.get(tid) or GENERATORS.get(tid, {})).get("recharge", 7.5)
            self._card_cooldowns[tid] = Cooldown(recharge, ready=True)
        self.hud.setup_cards(available, self._card_cooldowns)

        self._bg_variant = self.level_loader.get_background_variant()
        self._cached_bg = None

    # ─── Input handling ───────────────────────────────────────────────────────
    def handle_event(self, event) -> str | None:
        """Returns new game state string if state should change, else None."""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.paused = not self.paused
                return STATE_PAUSED if self.paused else None
            if event.key == pygame.K_r:
                self.load_level(self.current_level)
                return None
            if event.key == pygame.K_SPACE:
                self.level_loader.start_next_wave()
                return None

        if self.paused:
            return None

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            if event.button == 1:
                return self._handle_left_click(mx, my)
            elif event.button == 3:
                return self._handle_right_click(mx, my)

        if event.type == pygame.MOUSEMOTION:
            mx, my = event.pos
            self.grid.set_hover(mx, my)
            self.hud.handle_hover(mx, my)
            # Swipe scroll on card bar (touch drag)
            if event.buttons[0]:
                self.hud.handle_touch_drag(mx, my)

        return None

    def _handle_left_click(self, mx, my) -> str | None:
        # HUD click
        selected = self.hud.handle_click(mx, my, self.energy)
        if selected == "shovel":
            return None
        if selected:
            return None   # card selected, wait for grid click

        # Collect energy cores
        for core in self.energy_cores[:]:
            if core.alive and core.hit_test(mx, my):
                val = core.collect()
                self.energy += val
                self.particles.emit_energy_pulse(mx, my)
                self.energy_cores.remove(core)
                return None

        # Sell mode
        if self.hud.shovel_active:
            cell = self.grid.cell_at_pixel(mx, my)
            if cell and cell.occupant:
                refund = cell.occupant.cost // 2
                self.energy += refund
                self.grid.remove_unit(cell.col, cell.row)
                self.turrets = [t for t in self.turrets if t is not cell.occupant]
                self.particles.emit_burst(cell.rect.centerx, cell.rect.centery,
                                           COLORS["sell_color"], count=10, speed=60)
                self.hud.deselect()
            return None

        # Place turret
        selected_id = self.hud.get_selected_id()
        if selected_id:
            cell = self.grid.cell_at_pixel(mx, my)
            if cell and cell.is_empty():
                self._place_unit(selected_id, cell.col, cell.row)
                self.hud.deselect()
        return None

    def _handle_right_click(self, mx, my) -> str | None:
        self.hud.deselect()
        return None

    def _place_unit(self, turret_id: str, col: int, row: int):
        data = TURRETS.get(turret_id) or GENERATORS.get(turret_id)
        if not data:
            return
        cost = data["cost"]
        if self.energy < cost:
            return
        cd = self._card_cooldowns.get(turret_id)
        if cd and not cd.ready():
            return

        if turret_id in GENERATORS:
            unit = Generator(turret_id, col, row)
        else:
            unit = Turret(turret_id, col, row)

        if self.grid.place_unit(col, row, unit):
            self.energy -= cost
            self.turrets.append(unit)
            if cd:
                cd.use()
            self.particles.emit_burst(int(unit.x), int(unit.y),
                                       data["color"], count=8, speed=50, size=3, lifetime=0.4)

    # ─── Update ───────────────────────────────────────────────────────────────
    def update(self, dt: float) -> str | None:
        if self.paused:
            return None
        if self.result:
            return self.result

        self._bg_scroll += dt * 15

        # ── Card cooldowns ────────────────────────────────────────────────────
        for cd in self._card_cooldowns.values():
            cd.update(dt)

        # ── Grid update ───────────────────────────────────────────────────────
        self.grid.update(dt)

        # ── Generators: drop energy cores ────────────────────────────────────
        for turret in self.turrets:
            if isinstance(turret, Generator):
                drops = turret.should_drop()
                for dx, dy in drops:
                    self.energy_cores.append(EnergyCore(dx, dy))

        # ── Sky drops ────────────────────────────────────────────────────────
        new_cores = self.sky_drops.update(dt)
        self.energy_cores.extend(new_cores)

        # ── Energy cores update ───────────────────────────────────────────────
        for core in self.energy_cores[:]:
            core.update(dt)
            if not core.alive:
                self.energy_cores.remove(core)

        # ── Wave/spawn logic ──────────────────────────────────────────────────
        live_robots = [r for r in self.robots if r.alive]
        spawns = self.level_loader.update(dt, live_robots)
        for robot_id, lane in spawns:
            robot = Robot(robot_id, lane, start_col=GRID_COLS)
            self.level_loader.apply_world5_boost(robot)
            self.robots.append(robot)
            self.particles.emit_burst(
                int(GRID_OFFSET_X + GRID_COLS * CELL_W),
                int(GRID_OFFSET_Y + lane * CELL_H + CELL_H // 2),
                COLORS["neon_red"], count=6, speed=60, size=3, lifetime=0.3)

        # ── Turret updates ────────────────────────────────────────────────────
        live_robots = [r for r in self.robots if r.alive]
        new_placements = []
        for turret in self.turrets[:]:
            if not turret.alive:
                self.turrets.remove(turret)
                self.grid.remove_unit(turret.col, turret.row)
                self.particles.emit_explosion(int(turret.x), int(turret.y),
                                               turret.color, 30)
                continue
            result = turret.update(dt, live_robots, self.projectiles, self.particles,
                                    self.grid, self.turrets)
            for placement in result:
                new_placements.append(placement)

        # Replicator: place duplicate
        for (tid, col, row) in new_placements:
            if 0 <= col < GRID_COLS and 0 <= row < GRID_ROWS:
                cell = self.grid.cell_at(col, row)
                if cell and cell.is_empty():
                    self._place_unit(tid, col, row)
                    self.energy += (TURRETS.get(tid) or GENERATORS.get(tid, {})).get("cost", 0)  # free

        # ── Projectile updates ────────────────────────────────────────────────
        for proj in self.projectiles[:]:
            if not proj.alive:
                self.projectiles.remove(proj)
                continue
            result = proj.update(dt, live_robots, self.particles)
            if not proj.alive:
                self.projectiles.remove(proj)

        # ── Robot updates ─────────────────────────────────────────────────────
        new_robot_queue = []
        for robot in self.robots[:]:
            if not robot.alive:
                # Death effects
                spawned = robot.on_death(self.turrets, self.particles)
                new_robot_queue.extend(spawned)
                self.score += robot.score_value
                self.particles.emit_explosion(int(robot.x), int(robot.y),
                                               robot.color, 25)
                self.robots.remove(robot)
                continue

            result = robot.update(dt, self.turrets, self.robots, self.grid, self.particles)
            if isinstance(result, tuple):
                # Robot reached home
                new_spawns, reached_home = result
                new_robot_queue.extend(new_spawns)
                if reached_home:
                    self.robots_through += 1
                    self._trigger_emergency_drone(robot.lane)
                    self.robots.remove(robot)
                    if self.robots_through >= MAX_ROBOTS_THROUGH:
                        self.result = STATE_LOSE
                        return self.result
            elif isinstance(result, list):
                new_robot_queue.extend(result)

        # Add split/spawned robots
        for robot in new_robot_queue:
            self.level_loader.apply_world5_boost(robot)
            self.robots.append(robot)

        # ── Jammer effect ─────────────────────────────────────────────────────
        for robot in self.robots:
            if not robot.alive or not robot.jammer_active:
                continue
            for turret in self.turrets:
                d = math.sqrt((turret.x - robot.x) ** 2 + (turret.y - robot.y) ** 2)
                if d < robot.jammer_range:
                    turret.stun_timer = max(turret.stun_timer, 0.1)

        # ── Overclock boost ───────────────────────────────────────────────────
        for robot in self.robots:
            if not robot.alive or not robot.overclocker:
                continue
            for other in self.robots:
                if other is robot or not other.alive:
                    continue
                d = math.sqrt((other.x - robot.x) ** 2 + (other.y - robot.y) ** 2)
                if d < CELL_W * 2.5:
                    other.speed = min(other.base_speed * 2, other.speed * 1.02)

        # ── Drone animations ──────────────────────────────────────────────────
        self._update_drone_animations(dt)

        # ── Particles ─────────────────────────────────────────────────────────
        self.particles.update(dt)

        # ── Win condition ─────────────────────────────────────────────────────
        if self.level_loader.is_complete and not self.robots:
            self.result = STATE_WIN
            return self.result

        return None

    def _trigger_emergency_drone(self, lane: int):
        """Deploy a visible Emergency Drone that sweeps the full lane, destroying robots."""
        if self._emergency_drones[lane]:
            self._emergency_drones[lane] = False
            start_x = GRID_OFFSET_X + GRID_COLS * CELL_W + 40
            self._drone_animations.append({
                "lane": lane,
                "timer": 2.2,          # total animation seconds
                "x": float(start_x),
                "y": float(GRID_OFFSET_Y + lane * CELL_H + CELL_H // 2),
                "speed": 520,          # px/s — sweeps full grid in ~1.7s
                "has_killed": False,
            })

    def _update_drone_animations(self, dt):
        lane_grid_left = GRID_OFFSET_X - 50
        for anim in self._drone_animations[:]:
            anim["timer"] -= dt
            anim["x"] -= anim["speed"] * dt

            # Kill every robot in this lane while sweeping
            for robot in self.robots[:]:
                if not robot.alive:
                    continue
                if robot.lane != anim["lane"]:
                    continue
                if abs(robot.x - anim["x"]) < 55:
                    robot.hp = 0
                    robot.alive = False
                    self.particles.emit_explosion(int(robot.x), int(robot.y),
                                                   COLORS["drone_color"], 30)
                    self.score += robot.score_value

            if anim["timer"] <= 0:
                self._drone_animations.remove(anim)

    def _draw_drone(self, surface, anim):
        """Draw a visible lawnmower/drone sprite at the animation's current position."""
        cx = int(anim["x"])
        cy = int(anim["y"])
        t = anim["timer"]
        alpha = int(min(255, t * 200))
        color = COLORS["drone_color"]

        # Glow halo
        draw_glow(surface, cx, cy, 32, color, intensity=0.5)

        # Body — flat horizontal sled shape
        body = pygame.Rect(cx - 28, cy - 12, 56, 24)
        pygame.draw.rect(surface, (10, 40, 60), body, border_radius=6)
        pygame.draw.rect(surface, color, body, 2, border_radius=6)

        # Spinning blade underneath (rotates with time)
        blade_angle = pygame.time.get_ticks() * 0.015
        import math
        for i in range(4):
            a = blade_angle + i * math.pi / 2
            bx = cx + int(18 * math.cos(a))
            by = cy + 16 + int(4 * math.sin(a))
            pygame.draw.line(surface, color, (cx, cy + 14), (bx, by), 3)
        pygame.draw.circle(surface, color, (cx, cy + 14), 4)

        # Front arrow/chevron
        pygame.draw.polygon(surface, color, [
            (cx - 32, cy - 8), (cx - 44, cy), (cx - 32, cy + 8)
        ])

        # Cockpit window
        pygame.draw.ellipse(surface, (0, 180, 255, 160),
                             pygame.Rect(cx - 10, cy - 8, 20, 16))
        pygame.draw.ellipse(surface, color, pygame.Rect(cx - 10, cy - 8, 20, 16), 1)

        # "DRONE" label above
        render_text(surface, "⚡ EMERGENCY DRONE", cx, cy - 26,
                     color, size="tiny", center=True)

    # ─── Draw ─────────────────────────────────────────────────────────────────
    def draw(self, surface):
        # Background
        if self._cached_bg is None:
            self._cached_bg = pygame.Surface((SCREEN_W, SCREEN_H))
        draw_background(self._cached_bg, self._bg_variant, self._bg_scroll)
        surface.blit(self._cached_bg, (0, 0))

        # Grid
        self.grid.draw(surface)

        # Placement ghost
        if self.hud.get_selected_id():
            self._draw_placement_ghost(surface)

        # Generators (draw before turrets)
        for turret in self.turrets:
            if isinstance(turret, Generator):
                turret.draw(surface)

        # Turrets
        for turret in self.turrets:
            if not isinstance(turret, Generator):
                turret.draw(surface)

        # Projectiles
        for proj in self.projectiles:
            proj.draw(surface)

        # Robots
        for robot in self.robots:
            robot.draw(surface)

        # Energy cores
        for core in self.energy_cores:
            core.draw(surface)

        # Particles
        self.particles.draw(surface)

        # Emergency drone animations
        for anim in self._drone_animations:
            self._draw_drone(surface, anim)

        # Robot breach warning (top left)
        draw_robot_breach_warning(surface, self.robots_through, MAX_ROBOTS_THROUGH)

        # Emergency Drone indicators — one per lane on the left edge
        for lane in range(GRID_ROWS):
            ix = GRID_OFFSET_X - 52
            iy = GRID_OFFSET_Y + lane * CELL_H + CELL_H // 2
            if self._emergency_drones[lane]:
                # Drone ready — bright icon
                draw_glow(surface, ix, iy, 14, COLORS["drone_color"], intensity=0.4)
                pygame.draw.rect(surface, (10, 40, 60),
                                  pygame.Rect(ix - 14, iy - 9, 28, 18), border_radius=4)
                pygame.draw.rect(surface, COLORS["drone_color"],
                                  pygame.Rect(ix - 14, iy - 9, 28, 18), 1, border_radius=4)
                render_text(surface, "⚡", ix, iy, COLORS["drone_color"],
                             size="tiny", center=True, shadow=False)
            else:
                # Drone spent — dim
                pygame.draw.rect(surface, (20, 20, 25),
                                  pygame.Rect(ix - 14, iy - 9, 28, 18), border_radius=4)
                pygame.draw.rect(surface, COLORS["text_dim"],
                                  pygame.Rect(ix - 14, iy - 9, 28, 18), 1, border_radius=4)
                render_text(surface, "✗", ix, iy, COLORS["text_dim"],
                             size="tiny", center=True, shadow=False)

        # HUD
        nwcd = self.level_loader.next_wave_countdown
        self.hud.draw(
            surface, self.energy,
            self.level_loader.display_wave_num,
            self.level_loader.total_waves,
            nwcd if nwcd >= 0 else 0,
            self.level_loader.get_level_name(),
            self.score,
        )

        # Scanlines
        draw_scanline_overlay(surface)

    def _draw_placement_ghost(self, surface):
        """Draw a ghost of the turret being placed at hovered cell."""
        cell = self.grid.hovered_cell
        if not cell or not cell.is_empty():
            return
        selected_id = self.hud.get_selected_id()
        if not selected_id:
            return
        data = TURRETS.get(selected_id) or GENERATORS.get(selected_id)
        if not data:
            return
        ghost = pygame.Surface((CELL_W, CELL_H), pygame.SRCALPHA)
        ghost.fill((*data["color"], 50))
        pygame.draw.rect(ghost, (*data["color"], 120), (0, 0, CELL_W, CELL_H), 2)
        surface.blit(ghost, cell.rect.topleft)

    def draw_pause(self, surface):
        self.draw(surface)
        buttons = draw_pause_overlay(surface)
        return buttons
