"""
settings.py — Global constants, colors, and configuration for Turrets vs. Robots.
All magic numbers live here. Never hardcode values in game logic.
"""

import pygame

# ─── Screen ───────────────────────────────────────────────────────────────────
SCREEN_W = 1100
SCREEN_H = 700
FPS = 60
TITLE = "Turrets vs. Robots"

# ─── Grid ─────────────────────────────────────────────────────────────────────
GRID_COLS = 9
GRID_ROWS = 7
CELL_W = 90
CELL_H = 70
GRID_OFFSET_X = 60          # pixels from left edge to column 0
GRID_OFFSET_Y = 80          # pixels from top edge to row 0
HUD_TOP_H = 60              # top HUD bar height
HUD_BOT_H = 110             # bottom card bar height
GRID_TOTAL_W = GRID_COLS * CELL_W   # 810
GRID_TOTAL_H = GRID_ROWS * CELL_H   # 490

# ─── Colors ───────────────────────────────────────────────────────────────────
COLORS = {
    "bg_dark":        (10,  14,  26),
    "bg_mid":         (13,  22,  38),
    "grid_line":      (26,  35,  64),
    "grid_cell":      (13,  22,  38),
    "grid_hover":     (30,  55,  90),
    "neon_green":     (57,  255, 20),
    "neon_cyan":      (0,   255, 255),
    "neon_orange":    (255, 107, 0),
    "neon_red":       (255, 23,  68),
    "neon_yellow":    (255, 230, 0),
    "neon_purple":    (191, 0,   255),
    "neon_blue":      (0,   128, 255),
    "neon_pink":      (255, 0,   128),
    "ui_panel":       (17,  24,  39),
    "ui_border":      (42,  58,  92),
    "ui_border_hi":   (80,  120, 180),
    "text_primary":   (224, 240, 255),
    "text_secondary": (112, 144, 176),
    "text_dim":       (60,  80,  110),
    "white":          (255, 255, 255),
    "black":          (0,   0,   0),
    "hp_green":       (50,  220, 80),
    "hp_red":         (220, 50,  50),
    "hp_bar_bg":      (40,  40,  40),
    "card_bg":        (20,  30,  50),
    "card_border":    (50,  80,  130),
    "card_afford":    (57,  255, 20),
    "card_cant":      (80,  80,  80),
    "sell_color":     (255, 200, 0),
    "wave_color":     (255, 150, 50),
    "energy_color":   (255, 230, 0),
    "drone_color":    (0,   200, 255),
    "shadow":         (0,   0,   0, 120),
    "overlay_scan":   (0,   0,   0, 12),
}

# ─── Energy / Economy ─────────────────────────────────────────────────────────
ENERGY_START        = 150
ENERGY_CORE_VALUE   = 25
ENERGY_CORE_LIFETIME = 10.0   # seconds before fade
ENERGY_CORE_RADIUS  = 14
SKY_DROP_INTERVAL   = 12.0   # seconds between sky-drop cores (without generators)
SELL_REFUND         = 0.5    # fraction of cost returned on sell

# ─── Currency (Nano-Credits) ──────────────────────────────────────────────────
CURRENCY_NAME           = "NC"          # short symbol shown in UI
CURRENCY_PER_STAR       = 40            # NC per star earned
CURRENCY_PER_DRONE_LEFT = 15            # NC per unused emergency drone
CURRENCY_PERFECT_BONUS  = 30            # bonus for 0 robots through

# ─── Combat ───────────────────────────────────────────────────────────────────
MAX_ROBOTS_THROUGH  = 5      # robots reaching home before game over
DRONE_DAMAGE        = 9999   # emergency drone one-shots anything
DRONE_SPEED         = 400    # px/s animation

# ─── Particles ────────────────────────────────────────────────────────────────
MAX_PARTICLES       = 300
TRAIL_INTERVAL      = 0.03   # seconds between trail particles

# ─── Layers (Z-order) ─────────────────────────────────────────────────────────
LAYER_BG            = 0
LAYER_GRID          = 1
LAYER_TURRET        = 2
LAYER_PROJECTILE    = 3
LAYER_ROBOT         = 4
LAYER_ENERGY_CORE   = 5
LAYER_PARTICLE      = 6
LAYER_HUD           = 7
LAYER_OVERLAY       = 8

# ─── Game States ──────────────────────────────────────────────────────────────
STATE_MENU          = "menu"
STATE_LEVEL_SELECT  = "level_select"
STATE_PLAYING       = "playing"
STATE_PAUSED        = "paused"
STATE_WIN           = "win"
STATE_LOSE          = "lose"
STATE_HOW_TO_PLAY   = "how_to_play"

# ─── Fonts (loaded lazily after pygame.init) ──────────────────────────────────
FONT_SIZES = {
    "huge":   48,
    "large":  28,
    "medium": 20,
    "small":  15,
    "tiny":   12,
}

# ─── Misc ─────────────────────────────────────────────────────────────────────
SAVE_FILE = "save_data.json"
BETWEEN_WAVE_COUNTDOWN = 20.0   # auto-start next wave after this many seconds
CARD_BAR_SLOTS = 8              # turret cards shown at once
