# 🤖 Turrets vs Robots — Android APK Builder

This repo auto-builds an Android APK using **GitHub Actions** (free).
You don't need Android Studio, the Android SDK, or anything installed locally.

---

## ✅ How to get your APK (5 steps, ~30 minutes build time)

### Step 1 — Create a free GitHub account
Go to [github.com](https://github.com) and sign up if you don't have an account.

### Step 2 — Create a new repository
1. Click the **+** button (top right) → **New repository**
2. Name it anything, e.g. `turrets-vs-robots`
3. Set it to **Public** (required for free Actions minutes)
4. Click **Create repository**

### Step 3 — Upload this folder
On the empty repo page, click **"uploading an existing file"** (the link in the middle).

Drag and drop the **entire contents** of this zip into the upload area:
```
.github/
turrets_vs_robots/
README.md
```
> ⚠️ Make sure `.github/` folder is included — it contains the build instructions.

Click **Commit changes**.

### Step 4 — Watch it build
1. Click the **Actions** tab at the top of your repo
2. You'll see **"Build Android APK"** running (yellow spinner)
3. Wait ~25–35 minutes for the first build (it downloads the Android SDK)
4. Future builds are cached and take ~5 minutes

### Step 5 — Download your APK
1. Once the build shows a ✅ green tick, click on it
2. Scroll down to **Artifacts**
3. Click **TurretsVsRobots-APK** to download a zip containing your APK

---

## 📱 Installing the APK on your Android phone

1. **Transfer the APK** to your phone (email it, Google Drive, USB cable, etc.)
2. **Open it** on your phone
3. Android will ask to allow installs from unknown sources — tap **Settings → Allow**
4. Tap **Install**
5. Done! The game appears in your app drawer.

> **iPhone:** APKs don't work on iOS. Use the web version instead (see `deploy/` folder in the other zip).

---

## 🔄 Re-triggering a build manually

Go to **Actions → Build Android APK → Run workflow** → **Run workflow**

---

## 🐳 Alternative: Build locally with Docker

If you have Docker installed on a Linux/Mac machine:

```bash
docker run --rm -v $(pwd)/turrets_vs_robots:/app \
  kivy/buildozer android debug
# APK appears in turrets_vs_robots/bin/
```

---

## 📁 Project structure

```
.github/
  workflows/
    build-apk.yml        ← GitHub Actions build config
turrets_vs_robots/
  main.py                ← Game entry point
  buildozer.spec         ← Android build config
  settings.py
  game/                  ← Game systems
  data/                  ← Level & enemy data
  utils/                 ← Drawing & helpers
  icon.png               ← App icon
  splash.png             ← Loading screen
README.md                ← This file
```

---

## ⚙️ Build config (buildozer.spec)

| Setting | Value |
|---------|-------|
| Package name | `com.turretsgame.turretsvrobots` |
| Min Android | API 21 (Android 5.0+) |
| Target Android | API 33 (Android 13) |
| Architectures | arm64-v8a + armeabi-v7a |
| Orientation | Landscape |
| Fullscreen | Yes |

To change the version number, edit `version = 1.0` in `buildozer.spec`.
